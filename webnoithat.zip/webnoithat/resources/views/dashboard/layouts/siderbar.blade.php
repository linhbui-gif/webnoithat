<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">SB Admin <sup>2</sup></div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item active">
        <a class="nav-link" href="index.html">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        Quản lý website
    </div>

    <!-- Nav Item - Pages Collapse Menu -->


    <!-- Nav Item - Utilities Collapse Menu -->
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePage"
            aria-expanded="true" aria-controls="collapsePage">
            <i class="fa fa-pager"></i>
            <span>Quản lý trang</span>
        </a>
        <div id="collapsePage" class="collapse" aria-labelledby="headingUtilities"
            data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{route('pages.index')}}">Danh sách trang</a>
                <a class="collapse-item" href="{{route('pages.create')}}">Thêm trang</a>
            </div>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseNew"
            aria-expanded="true" aria-controls="collapseNew">
            <i class="fa fa-address-card"></i>
            <span>Quản lý bài viết</span>
        </a>
        <div id="collapseNew" class="collapse" aria-labelledby="headingUtilities"
            data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{route('news.index')}}">Danh sách bài viết</a>
                <a class="collapse-item" href="{{route('newCate.index')}}">Danh mục bài viết</a>
            </div>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseProduct"
            aria-expanded="true" aria-controls="collapseProduct">
            <i class="fa fa-address-card"></i>
            <span>Quản lý sản phẩm</span>
        </a>
        <div id="collapseProduct" class="collapse" aria-labelledby="headingUtilities"
            data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{route('products.index')}}">Danh sách sản phẩm</a>
                <a class="collapse-item" href="{{route('products.create')}}">Thêm sản phẩm</a>
            </div>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseProductCate"
            aria-expanded="true" aria-controls="collapseProductCate">
            <i class="fa fa-address-card"></i>
            <span>Danh mục sản phẩm</span>
        </a>
        <div id="collapseProductCate" class="collapse" aria-labelledby="headingUtilities"
            data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{route('product-categories.index')}}">Ds danh mục sản phẩm</a>
                <a class="collapse-item" href="{{route('product-categories.create')}}">Thêm sản danh mục phẩm</a>
            </div>
        </div>
    </li>

    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities"
            aria-expanded="true" aria-controls="collapseUtilities">
            <i class="fa fa-sliders-h"></i>
            <span>Quản lý Slider</span>
        </a>
        <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities"
            data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{route('sliders.index')}}">Danh sách slider</a>
                <a class="collapse-item" href="{{route('sliders.create')}}">Thêm slider</a>
            </div>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseService"
            aria-expanded="true" aria-controls="collapseService">
            <i class="fa fa-concierge-bell"></i>
            <span>Quản lý service</span>
        </a>
        <div id="collapseService" class="collapse" aria-labelledby="headingUtilities"
            data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{route('services.index')}}">Danh sách service</a>
                <a class="collapse-item" href="{{route('services.create')}}">Thêm service</a>
            </div>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseCustomer"
            aria-expanded="true" aria-controls="collapseService">
            <i class="fa fa-concierge-bell"></i>
            <span>Quản lý khách hàng</span>
        </a>
        <div id="collapseCustomer" class="collapse" aria-labelledby="headingUtilities"
            data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{route('customers.index')}}">Danh sách khách hàng</a>
            </div>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseClient"
            aria-expanded="true" aria-controls="collapseClient">
            <i class="fa fa-burn"></i>
            <span>Khách hàng đánh giá</span>
        </a>
        <div id="collapseClient" class="collapse" aria-labelledby="headingUtilities"
            data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{route('clients.index')}}">Danh sách đánh giá</a>
                <a class="collapse-item" href="{{route('clients.create')}}">Thêm đánh giá</a>
            </div>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePartner"
            aria-expanded="true" aria-controls="collapsePartner">
            <i class="fa fa-handshake"></i>
            <span>Quản lý đối tác</span>
        </a>
        <div id="collapsePartner" class="collapse" aria-labelledby="headingUtilities"
            data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{route('partners.index')}}">Danh sách đối tác</a>
                <a class="collapse-item" href="{{route('partners.create')}}">Thêm đối tác</a>
            </div>
        </div>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        Hệ thống
    </div>

    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUser"
            aria-expanded="true" aria-controls="collapseUser">
            <i class="fa fa-user"></i>
            <span>Quản lý người dùng</span>
        </a>
        <div id="collapseUser" class="collapse" aria-labelledby="headingUtilities"
            data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{route('users.index')}}">Danh sách người dùng</a>
                <a class="collapse-item" href="{{route('users.create')}}">Thêm người dùng</a>
            </div>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSetting"
            aria-expanded="true" aria-controls="collapseSetting">
            <i class="fa fa-setting"></i>
            <span>Quản lý cài đặt</span>
        </a>
        <div id="collapseSetting" class="collapse" aria-labelledby="headingUtilities"
            data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{route('settings.index')}}">Danh sách cài đặt</a>

            </div>
        </div>
    </li>
    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul>