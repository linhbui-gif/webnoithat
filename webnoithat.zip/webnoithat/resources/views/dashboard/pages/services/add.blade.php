@extends('dashboard.master')
@section('content')
    @include('dashboard.layouts.content-header', ['name' => 'service', 'key' => 'Thêm'])
    <form action="{{ route('services.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="form-group">
            <label>Nội dung</label>
            <textarea class="form-control @error('content') is-invalid @enderror" name="content" placeholder="Nhập nội dung..."></textarea>
            @error('content')
                <div class="alert alert-danger  mt-2">{{ $message }}</div>
            @enderror
        </div>

        <div class="form-group">
            <label>Ảnh service</label>
            <input type="file"
                   class="form-control-file"
                   name="image_path"
            >
        </div>
        <div class="form-check mb-3">
            <input class="form-check-input" type="checkbox" id="inlineCheckbox1" name="type_choose" value="1">
            <label class="form-check-label" for="inlineCheckbox1">Hiển thị cho phần tại sao bạn chọn chúng tôi</label>
        </div>
        <button type="submit" class="btn btn-primary">Thêm service</button>
        <button type="button" class="btn btn-info"><a href="{{route('services.index')}}" style="color: white;text-decoration: none;"> Trở về</a></button>
    </form>
@endsection
