@extends('dashboard.master')
@section('content')
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        @include('dashboard.layouts.content-header', ['name' => ' đánh giá khách hàng', 'key' => 'Danh sách'])
        <a href="{{ route('news.create') }}" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-plus fa-sm text-white-50"></i> Thêm bài viết</a>
    </div>
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Tên</th>
                            <th>Mô tả</th>
                            <th >Nội dung </th>
                            <th >Tin tức nổi bật </th>
                            <th>Hình ảnh</th>
                            <th>Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($news as $newItem)
                            <tr>
                                <td>{{ $newItem->id }}</td>
                                <td>{{ $newItem->title }}</td>
                                <td style="width: 300px">{{ $newItem->description }}</td>
                                <td style="width: 300px">{{ $newItem->content }}</td>
                                <td>{{ $newItem->features === 0 ? "Tin tức nổi bật" : "" }}</td>
                                <td>
                                   <img src="{{ $newItem->image_path }}" width="200" alt="">
                                </td>
                                <td>
                                    <a href="{{ route('news.edit', ['id' => $newItem->id]) }}"
                                        class="btn btn-danger btn-circle">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="{{ route('news.delete', ['id' => $newItem->id]) }}"
                                        class="btn btn-danger btn-circle">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        @endforeach

                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
