@extends('dashboard.master')
@section('content')
    @include('dashboard.layouts.content-header', ['name' => ' bài viết', 'key' => 'Thêm'])
    <form action="{{ route('news.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="form-group">
            <label>Tên</label>
            <input class="form-control @error('title') is-invalid @enderror" name="title" placeholder="Nhập tên..." >
            @error('title')
                <div class="alert alert-danger  mt-2">{{ $message }}</div>
            @enderror
        </div>
        <div class="form-group">
            <label>Mô tả</label>
            <input class="form-control @error('description') is-invalid @enderror" name="description" placeholder="Nhập mô tả...">
            @error('description')
                <div class="alert alert-danger  mt-2">{{ $message }}</div>
            @enderror
        </div>
        <div class="form-group">
            <label for="exampleFormControlSelect1">Nhập danh mục cho bài viết</label>
            <select class="form-control" id="exampleFormControlSelect1" name="post_id">
                <option value="">Chọn danh mục</option>
                {!! $htmlOpition !!}
            </select>
          </div>
        <div class="form-group">
            <label>Nội dung</label>
            <textarea class="form-control tinymce_editor_init"  rows="10" name="content"></textarea>
        </div>
        <div class="form-group">
            <label>Ảnh bài viết</label>
            <input type="file"
                   class="form-control-file"
                   name="image_path"
            >
        </div>
        <div class="form-check mb-3">
            <input class="form-check-input" type="checkbox" value="1" name="features" id="defaultCheck1">
            <label class="form-check-label" for="defaultCheck1">
              Hiển thị là bài viết nổi bật
            </label>
          </div>
        <button type="submit" class="btn btn-primary">Thêm bài viết</button>
        <button type="button" class="btn btn-info"><a href="{{route('news.index')}}" style="color: white;text-decoration: none;"> Trở về</a></button>
    </form>
@endsection
