@extends('dashboard.master')
@section('content')
    @include('dashboard.layouts.content-header', ['name' => '', 'key' => 'Sửa'])
    <form action="{{ route('partners.update',['id'=> $partner ?? ''->id]) }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="form-group">
            <label>Hình ảnh</label>
            <input type="file"
                   class="form-control-file"
                   name="image_path"
            >
            <div class="col-md-4 feature_image_container">
                <div class="row">
                    <img class="feature_image" width="200" src="{{ $partner ?? ''->image_path }}" alt="">
                </div>
            </div>
        </div>
        <div class="form-check mb-3">
            <input class="form-check-input" type="checkbox" id="inlineCheckbox1" name="features" value="1"
            @if ($partner ->features == 1)
                {{"checked"}}
            @endif
            >
            <label class="form-check-label" for="inlineCheckbox1">Hiển thị là logo</label>
        </div>
        <button type="submit" class="btn btn-primary">Sửa đối tác</button>
        <button type="button" class="btn btn-info"><a href="{{route('partners.index')}}" style="color: white;text-decoration: none;"> Trở về</a></button>
    </form>
@endsection
