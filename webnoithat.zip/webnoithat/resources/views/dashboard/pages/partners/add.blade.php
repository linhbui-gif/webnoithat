@extends('dashboard.master')
@section('content')
    @include('dashboard.layouts.content-header', ['name' => '', 'key' => 'Thêm'])
    <form action="{{ route('partners.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="form-group">
            <label>Hình ảnh</label>
            <input type="file"
                   class="form-control-file"
                   name="image_path"
            >
        </div>
        <div class="custom-control custom-checkbox mb-4">
            <input type="checkbox" class="custom-control-input" value="1" name="features" id="customCheck1">
            <label class="custom-control-label" for="customCheck1">Hiển thị là ảnh Logo</label>
          </div>
        <button type="submit" class="btn btn-primary">Thêm partner</button>
        <button type="button" class="btn btn-info"><a href="{{route('partners.index')}}" style="color: white;text-decoration: none;"> Trở về</a></button>
    </form>
@endsection
