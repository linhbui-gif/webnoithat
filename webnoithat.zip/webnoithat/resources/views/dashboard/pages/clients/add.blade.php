@extends('dashboard.master')
@section('content')
    @include('dashboard.layouts.content-header', ['name' => ' đánh giá khách hàng', 'key' => 'Thêm'])
    <form action="{{ route('clients.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="form-group">
            <label>Tên</label>
            <input class="form-control @error('name') is-invalid @enderror" name="name" placeholder="Nhập tên..." >
            @error('name')
                <div class="alert alert-danger  mt-2">{{ $message }}</div>
            @enderror
        </div>
        <div class="form-group">
            <label>Quê quán</label>
            <input class="form-control @error('country') is-invalid @enderror" name="country" placeholder="Nhập quê quán...">
            @error('country')
                <div class="alert alert-danger  mt-2">{{ $message }}</div>
            @enderror
        </div>
        <div class="form-group">
            <label>Nội dung</label>
            <textarea class="form-control @error('content') is-invalid @enderror" name="content" placeholder="Nhập nội dung..."></textarea>
            @error('content')
                <div class="alert alert-danger  mt-2">{{ $message }}</div>
            @enderror
        </div>

        <div class="form-group">
            <label>Ảnh khách hàng</label>
            <input type="file"
                   class="form-control-file"
                   name="image_path"
            >
        </div>
        <button type="submit" class="btn btn-primary">Thêm đánh giá khách hàng</button>
        <button type="button" class="btn btn-info"><a href="{{route('services.index')}}" style="color: white;text-decoration: none;"> Trở về</a></button>
    </form>
@endsection
