@extends('dashboard.master')
@section('content')
    @include('dashboard.layouts.content-header', ['name' => ' đánh giá khách hàng', 'key' => 'Sửa'])
    <form action="{{ route('clients.update',['id'=> $client->id]) }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="form-group">
            <label>Tên</label>
            <input class="form-control @error('name') is-invalid @enderror" name="name" placeholder="Nhập tên..." value="{{$client->name}}">
            @error('name')
                <div class="alert alert-danger  mt-2">{{ $message }}</div>
            @enderror
        </div>
        <div class="form-group">
            <label>Quê quán</label>
            <input class="form-control @error('country') is-invalid @enderror" name="country" placeholder="Nhập quê quán..." value="{{$client->country}}"></textarea>
            @error('country')
                <div class="alert alert-danger  mt-2">{{ $message }}</div>
            @enderror
        </div>
        <div class="form-group">
            <label>Nội dung</label>
            <textarea class="form-control @error('content') is-invalid @enderror" name="content" placeholder="Nhập nội dung...">{{$client->content}}</textarea>
            @error('content')
                <div class="alert alert-danger  mt-2">{{ $message }}</div>
            @enderror
        </div>

        <div class="form-group">
            <label>Ảnh khách hàng</label>
            <input type="file"
                   class="form-control-file"
                   name="image_path"
            >
            <div class="col-md-4 feature_image_container">
                <div class="row">
                    <img class="feature_image" width="200" src="{{ $client->image_path }}" alt="">
                </div>
            </div>
        </div>
        <button type="submit" class="btn btn-primary">Sửa đánh giá khách hàng</button>
        <button type="button" class="btn btn-info"><a href="{{route('clients.index')}}" style="color: white;text-decoration: none;"> Trở về</a></button>
    </form>
@endsection
