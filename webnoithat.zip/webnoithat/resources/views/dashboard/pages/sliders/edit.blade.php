@extends('dashboard.master')
@section('content')
    @include('dashboard.layouts.content-header', ['name' => 'slider', 'key' => 'Sửa'])
    <form action="{{ route('sliders.update',['id'=> $slider->id]) }}" method="post" enctype="multipart/form-data">
        @csrf
        <div class="form-group">
            <label>Tên slider</label>
        <input type="text" class="form-control" name="title" placeholder="Nhập tên slider..." value="{{$slider->title}}">
        </div>
        <div class="form-group">
            <label>Mô tả</label>
            <input type="text" class="form-control" name="description" value="{{$slider->description}}" placeholder="Nhập mô tả...">
        </div>

        <div class="form-group">
            <label>Ảnh Slider</label>
            <input type="file"
                   class="form-control-file"
                   name="image_path"
            >
            <div class="col-md-4 feature_image_container">
                <div class="row">
                    <img class="feature_image" width="200" src="{{ $slider->image_path }}" alt="">
                </div>
            </div>
        </div>
        <div class="custom-control custom-checkbox mb-4">
            <input type="checkbox" class="custom-control-input" id="customCheck1"  name="features"
            @if ($slider->features == 1)
                {{"checked"}}
            @endif
            >
            <label class="custom-control-label" for="customCheck1">Hiển thị là ảnh Banner trang chủ</label>
          </div>
        <button type="submit" class="btn btn-primary">Sửa slider</button>
        <button type="button" class="btn btn-info"><a href="{{route('sliders.index')}}" style="color: white;text-decoration: none;"> Trở về</a></button>
    </form>
@endsection
