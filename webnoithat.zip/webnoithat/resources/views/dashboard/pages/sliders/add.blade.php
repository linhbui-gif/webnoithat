@extends('dashboard.master')
@section('content')
    @include('dashboard.layouts.content-header', ['name' => 'slider', 'key' => 'Thêm'])
    <form action="{{ route('sliders.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="form-group">
            <label>Tên slider</label>
            <input type="text" class="form-control @error('title') is-invalid @enderror" name="title" placeholder="Nhập tên slider...">
            @error('title')
                <div class="alert alert-danger mt-2">{{ $message }}</div>
            @enderror
        </div>
        <div class="form-group">
            <label>Mô tả</label>
            <input type="text" class="form-control @error('description') is-invalid @enderror" name="description" placeholder="Nhập mô tả...">
            @error('description')
                <div class="alert alert-danger  mt-2">{{ $message }}</div>
            @enderror
        </div>

        <div class="form-group">
            <label>Ảnh Slider</label>
            <input type="file"
                   class="form-control-file"
                   name="image_path"
            >
        </div>
        <div class="custom-control custom-checkbox mb-4">
            <input type="checkbox" class="custom-control-input" value="1" name="features" id="customCheck1">
            <label class="custom-control-label" for="customCheck1">Hiển thị là ảnh Banner trang chủ</label>
          </div>
        <button type="submit" class="btn btn-primary">Thêm slider</button>
        <button type="button" class="btn btn-info"><a href="{{route('sliders.index')}}" style="color: white;text-decoration: none;"> Trở về</a></button>
    </form>
@endsection
