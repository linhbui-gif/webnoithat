@extends('dashboard.master')
@section('content')
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        @include('dashboard.layouts.content-header', ['name' => 'người dùng', 'key' => 'Danh sách'])
        <a href="{{ route('users.create') }}" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-plus fa-sm text-white-50"></i> Thêm người dùng</a>
    </div>
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Tên</th>
                            <th>Email</th>
                            <th>Hình ảnh</th>
                            <th>Quyền</th>
                            <th>Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($users as $userItem)
                            <tr>
                                <td>{{ $userItem->id }}</td>
                                <td>{{ $userItem->name }}</td>
                                <td>{{ $userItem->email }}</td>
                                <td>
                                   <img src="{{ $userItem->image_path }}" width="200" alt="">
                                </td>
                                <td>{{ $userItem->roles === 0 ? "admin" : "user" }}</td>
                                <td>
                                    <a href="{{ route('users.edit', ['id' => $userItem->id]) }}"
                                        class="btn btn-danger btn-circle">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="{{ route('users.delete', ['id' => $userItem->id]) }}"
                                        class="btn btn-danger btn-circle">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        @endforeach

                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
