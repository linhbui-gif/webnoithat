@extends('dashboard.master')
@section('content')
    @include('dashboard.layouts.content-header', ['name' => 'user', 'key' => 'Thêm'])
    <form action="{{ route('users.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="form-group">
            <label>Tên</label>
            <input type="text"
                   class="form-control @error('name') is-invalid @enderror"
                   name="name"
            >
            @error('name')
                <div class="alert alert-danger  mt-2">{{ $message }}</div>
            @enderror
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="text"
                   class="form-control @error('email') is-invalid @enderror"
                   name="email"
            >
            @error('email')
            <div class="alert alert-danger  mt-2">{{ $message }}</div>
            @enderror
        </div>
        <div class="form-group">
            <label>Mật khẩu</label>
            <input type="password"
                   class="form-control @error('password') is-invalid @enderror"
                   name="password"
            >
            @error('password')
            <div class="alert alert-danger  mt-2">{{ $message }}</div>
            @enderror
        </div>
        <div class="form-group">
            <label>Nhập lại mật khẩu</label>
            <input type="password"
                   class="form-control @error('repassword') is-invalid @enderror"
                   name="repassword"
            >
            @error('repassword')
            <div class="alert alert-danger  mt-2">{{ $message }}</div>
            @enderror
        </div>
        <div class="form-group">
            <label>Hình ảnh</label>
            <input type="file"
                   class="form-control-file"
                   name="image_path"
            >
        </div>
        <div class="form-group">
            <label for="exampleFormControlSelect1">Chọn quyền</label>
            <select class="form-control" id="exampleFormControlSelect1" name="roles">
              <option value="0">Admin</option>
              <option value="1">User</option>
            </select>
          </div>
        <button type="submit" class="btn btn-primary">Thêm người dùng</button>
        <button type="button" class="btn btn-info"><a href="{{route('users.index')}}" style="color: white;text-decoration: none;"> Trở về</a></button>
    </form>
@endsection
