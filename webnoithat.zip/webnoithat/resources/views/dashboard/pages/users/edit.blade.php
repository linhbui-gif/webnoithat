@extends('dashboard.master')
@section('content')
    @include('dashboard.layouts.content-header', ['name' => 'user', 'key' => 'Sửa'])
    <form action="{{ route('users.update',['id'=> $user->id]) }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="form-group">
            <label>Tên</label>
            <input type="text"
                   class="form-control @error('name') is-invalid @enderror"
                   name="name"
                   value="{{$user->name}}"
            >
            @error('name')
                <div class="alert alert-danger  mt-2">{{ $message }}</div>
            @enderror
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="text"
                   class="form-control @error('email') is-invalid @enderror"
                   name="email"
                   value="{{$user->email}}"
                   readonly
            >
            @error('email')
            <div class="alert alert-danger  mt-2">{{ $message }}</div>
            @enderror
        </div>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="changePassword" id="changePassword">
            <label class="form-check-label" for="defaultCheck1">
                Đổi mật khẩu
            </label>
        </div>
        <div class="form-group">
            <input type="password"
                   class="form-control @error('password') is-invalid @enderror password"
                   name="password"
                   disabled
            >
            @error('password')
            <div class="alert alert-danger  mt-2">{{ $message }}</div>
            @enderror
        </div>
        <div class="form-group">
            <label>Nhập lại mật khẩu</label>
            <input type="password"
                   disabled
                   class="form-control @error('repassword') is-invalid @enderror password"
                   name="repassword"
            >
            @error('repassword')
            <div class="alert alert-danger  mt-2">{{ $message }}</div>
            @enderror
        </div>
        <div class="form-group">
            <label>Hình ảnh</label>
            <input type="file"
                   class="form-control-file"
                   name="image_path"
            >
            <div class="col-md-4 feature_image_container">
                <div class="row">
                    <img class="feature_image" width="200" src="{{ $user->image_path }}" alt="">
                </div>
            </div>
        </div>
        <div class="form-group">
            <label for="exampleFormControlSelect1">Chọn quyền</label>
            <select class="form-control" id="exampleFormControlSelect1" name="roles">
              <option value="0"
              @if ($user->roles === 0)
                  {{"checked"}}
              @endif
              >Admin</option>
              <option value="1"
              @if ($user->roles == 1)
                  {{"checked"}}
              @endif
              >User</option>
            </select>
          </div>
        <button type="submit" class="btn btn-primary">Sửa người dùng</button>
        <button type="button" class="btn btn-info"><a href="{{route('users.index')}}" style="color: white;text-decoration: none;"> Trở về</a></button>
    </form>
@endsection
@section('js')
    <script>
        $(document).ready(function(){
              $("#changePassword").change(function(){
                  if($(this).is(":checked")){
                      $(".password").removeAttr('disabled')
                  }
                  else{
                    $(".password").attr('disabled','')
                  }
              })
        })
    </script>
@endsection