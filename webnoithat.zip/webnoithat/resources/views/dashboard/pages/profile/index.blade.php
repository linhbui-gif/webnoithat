@extends('dashboard.master')
@section('content')
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        @include('dashboard.layouts.content-header', ['name' => 'người dùng', 'key' => 'Thông tin'])
        <a href="{{ route('users.create') }}" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-plus fa-sm text-white-50"></i> Thông tin người dùng</a>
    </div>
    <ul class="list-group list-group-flush">
        <li class="list-group-item">Họ và Tên : {{$user->name}}</li>
        <li class="list-group-item">Email : {{$user->email}}</li>
        <li class="list-group-item">Hình ảnh : <img src="{{$user->image_path}}" width="300" alt=""></li>
        <li class="list-group-item">Quyền : {{$user->roles === 0 ? "admin" : "user"}}</li>
      </ul>
@endsection
