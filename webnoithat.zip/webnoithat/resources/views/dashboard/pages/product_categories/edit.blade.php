@extends('dashboard.master')
@section('content')
    @include('dashboard.layouts.content-header', ['name' => 'danh mục sản phẩm', 'key' => 'Sửa'])
    <form action="{{ route('product-categories.update',['id'=>$product_cateEdit->id]) }}" method="post">
        @csrf
        <div class="form-group">
            <label>Tên danh mục</label>
            <input type="text" class="form-control @error('name') is-invalid @enderror" name="name" placeholder="Nhập tên danh mục sản phẩm" value="{{$product_cateEdit->name}}">
            @error('name')
                <div class="alert alert-danger mt-2">{{ $message }}</div>
            @enderror
        </div>

        <div class="form-group">
            <label >Danh mục cha</label>
            <select class="form-control" name="parent_id">
              <option value="0">Chọn danh mục cha</option>
              {!! $htmlOpition !!}
            </select>
          </div>

        <button type="submit" class="btn btn-primary">Sửa danh mục sản phẩm</button>
        <button type="button" class="btn btn-info"><a href="{{route('product-categories.index')}}" style="color: white;text-decoration: none;"> Trở về</a></button>
    </form>
@endsection
