@extends('dashboard.master')
@section('content')
    @include('dashboard.layouts.content-header', ['name' => 'menu', 'key' => 'Thêm'])
    <form action="{{ route('menus.update',['id'=>$menuFollowIdEdit->id]) }}" method="POST">
        @csrf
        <div class="form-group">
            <label>Tên menu</label>
            <input type="text" class="form-control" name="name" value="{{ $menuFollowIdEdit->name }}" placeholder="Nhập tên menu">
        </div>

        <div class="form-group">
            <label>Chọn menu cha</label>
            <select class="form-control" name="parent_id">
                <option value="0">Chọn menu cha</option>
                {!! $optionSelect !!}
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Sửa Menu</button>
        <button type="button" class="btn btn-info"><a href="{{route('menus.index')}}" style="color: white;text-decoration: none;"> Trở về</a></button>
    </form>
@endsection
