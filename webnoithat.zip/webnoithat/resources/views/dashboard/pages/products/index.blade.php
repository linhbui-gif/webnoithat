@extends('dashboard.master')
@section('content')
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        @include('dashboard.layouts.content-header', ['name' => ' sản phẩm', 'key' => 'Danh sách'])
        <a href="{{ route('products.create') }}" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-plus fa-sm text-white-50"></i> Thêm sản phẩm</a>
    </div>
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Tên sản phẩm</th>
                            <th>Chủ đầu tư</th>
                            <th>Mã số CT</th>
                            <th>Nội dung </th>
                            <th>SP liên quan</th>
                            <th>Hình ảnh</th>
                            <th>Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($products as $productItem)
                            <tr>
                                <td>{{ $productItem->id }}</td>
                                <td>{{ $productItem->title }}</td>
                                <td >{{ $productItem->investor }}</td>
                                <td >{{ $productItem->code_ct }}</td>
                                <td>{{ $productItem->content}}</td>
                                {{-- <td>{{optional($productItem->category)->name}}</td> --}}
                                <td>{{$productItem->related_product == 1 ? "Nổi bật" : ""}}</td>
                                <td>
                                   <img src="{{ $productItem->image_path }}" width="200" alt="">
                                </td>
                                <td>
                                    <a href="{{ route('products.edit', ['id' => $productItem->id]) }}"
                                        class="btn btn-danger btn-circle">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="{{ route('products.delete', ['id' => $productItem->id]) }}"
                                        class="btn btn-danger btn-circle">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        @endforeach

                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
