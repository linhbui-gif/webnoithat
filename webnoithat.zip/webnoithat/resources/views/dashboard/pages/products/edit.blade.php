@extends('dashboard.master')
@section('content')
    @include('dashboard.layouts.content-header', ['name' => ' sản phẩm', 'key' => 'Sửa'])
    <form action="{{ route('products.update',['id'=>$product->id]) }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="form-group">
            <label>Tên sản phẩm</label>
            <input class="form-control @error('title') is-invalid @enderror" name="title" value="{{$product->title}}" placeholder="Nhập tên..." >
            @error('title')
                <div class="alert alert-danger  mt-2">{{ $message }}</div>
            @enderror
        </div>
        <div class="form-group">
            <label>Chủ đầu tư</label>
            <input class="form-control @error('investor') is-invalid @enderror" name="investor" placeholder="Nhập chủ đầu tư..." value="{{$product->investor}}">
            @error('investor')
                <div class="alert alert-danger  mt-2">{{ $message }}</div>
            @enderror
        </div>
        <div class="form-group">
            <label>Mã code CT</label>
        <input class="form-control @error('code_ct') is-invalid @enderror" name="code_ct" placeholder="Nhập mã CT..." value="{{$product->code_ct}}">
            @error('code_ct')
                <div class="alert alert-danger  mt-2">{{ $message }}</div>
            @enderror
        </div>
        <div class="form-group">
            <label for="exampleFormControlSelect1">Nhập danh mục cho sản phẩm</label>
            <select class="form-control" id="exampleFormControlSelect1" name="category_id">
                <option value="">Chọn danh mục</option>
                {!! $htmlOption !!}
            </select>
          </div>
        <div class="form-group">
            <label>Nội dung</label>
            <textarea class="form-control tinymce_editor_product"  rows="10" name="content">{!! $product->content !!}</textarea>
        </div>
        <div class="form-group">
            <label>Ảnh sản phẩm</label>
            <input type="file"
                   class="form-control-file"
                   name="image_path"
            >
            <div class="col-md-4 feature_image_container">
                <div class="row">
                    <img class="feature_image" width="200" src="{{ $product->image_path }}" alt="">
                </div>
            </div>
        </div>
        <div class="form-check mb-3">
            <input class="form-check-input" type="checkbox" value="1" name="related_product"
            @if ($product->related_product == 1)
                {{"checked"}}
            @endif
            id="defaultCheck1">
            <label class="form-check-label" for="defaultCheck1">
              Hiển thị là sản phẩm nổi bật
            </label>
        </div>
        <button type="submit" class="btn btn-primary">Sửa sản phẩm</button>
        <button type="button" class="btn btn-info"><a href="{{route('products.index')}}" style="color: white;text-decoration: none;"> Trở về</a></button>
    </form>
@endsection
