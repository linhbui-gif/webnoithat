@extends('dashboard.master')
@section('content')
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        @include('dashboard.layouts.content-header', ['name' => 'khách hàng', 'key' => 'Danh sách'])
    </div>
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Tên khách hàng</th>
                            <th>Email</th>
                            <th>Số điện thoại</th>
                            <th>Nội dung</th>
                            <th>Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($customers as $customerItem)
                            <tr>
                                <td>{{ $customerItem->id }}</td>
                                <td>{{ $customerItem->name }}</td>
                                <td>{{ $customerItem->email }}</td>
                                <td>{{ $customerItem->phone }}</td>
                                <td>{{ $customerItem->content }}</td>
                                <td>
                                    <a href="{{ route('customers.detail', ['id' => $customerItem->id]) }}"
                                        class="btn btn-danger btn-circle">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="{{ route('customers.delete', ['id' => $customerItem->id]) }}"
                                        class="btn btn-danger btn-circle">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        @endforeach

                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
