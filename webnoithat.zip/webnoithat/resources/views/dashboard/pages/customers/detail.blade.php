@extends('dashboard.master')
@section('content')
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        @include('dashboard.layouts.content-header', ['name' => 'khách hàng', 'key' => 'Thông tin'])
    </div>
    <ul class="list-group list-group-flush">
        <li class="list-group-item">Họ và Tên : {{$customer->name}}</li>
        <li class="list-group-item">Email : {{$customer->email}}</li>
        <li class="list-group-item">Số điện thoại : {{$customer->phone}}</li>
        <li class="list-group-item">Nội dung : {{$customer->content}}</li>
      </ul>
@endsection
