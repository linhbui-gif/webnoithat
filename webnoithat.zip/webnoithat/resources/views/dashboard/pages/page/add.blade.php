@extends('dashboard.master')
@section('content')
    @include('dashboard.layouts.content-header', ['name' => ' trang', 'key' => 'Thêm'])
    <form action="{{ route('pages.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="form-group">
            <label>Nội dung</label>
            <textarea class="form-control tinymce_editor_page"  rows="10" name="content"></textarea>
        </div>
        <div class="form-check mb-3">
            <input class="form-check-input" type="checkbox" value="1" name="type_pages" id="defaultCheck1">
            <label class="form-check-label" for="defaultCheck1">
              Hiển thị là trang liên hệ
            </label>
          </div>
        <button type="submit" class="btn btn-primary">Thêm trang</button>
        <button type="button" class="btn btn-info"><a href="{{route('pages.index')}}" style="color: white;text-decoration: none;"> Trở về</a></button>
    </form>
@endsection
