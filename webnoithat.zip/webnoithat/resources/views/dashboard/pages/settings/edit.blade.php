@extends('dashboard.master')
@section('content')
    @include('dashboard.layouts.content-header', ['name' => 'slider', 'key' => 'Sửa'])
    <form action="{{ route('settings.update',['id' => $setting->id]) }}" method="post">
        @csrf
        <div class="form-group">
            <label>Cấu hình tên</label>
            <input type="text"
                   class="form-control"
                   name="config_key"
                   placeholder="Nhập tên cài đặt..."
                   value="{{ $setting->config_key }}"
            >
        </div>
        @if(request()->type === 'Text')
            <div class="form-group">
                <label>Cấu hình giá trị</label>
                <input type="text"
                       class="form-control"
                       name="config_value"
                       placeholder="Nhập giá trị..."
                       value="{{ $setting->config_value }}"
                >
            </div>
            @elseif(request()->type === 'Textarea')
            <div class="form-group">
                <label>Cấu hình giá trị</label>
                <textarea
                       class="form-control"
                       name="config_value"
                       placeholder="Nhập config value"
                       rows="5"
                >{{ $setting->config_value }}</textarea>
            </div>

        @endif
        <button type="submit" class="btn btn-primary">Sửa cài đặt</button>
        <button type="button" class="btn btn-info"><a href="{{route('settings.index')}}" style="color: white;text-decoration: none;"> Trở về</a></button>
    </form>
@endsection
