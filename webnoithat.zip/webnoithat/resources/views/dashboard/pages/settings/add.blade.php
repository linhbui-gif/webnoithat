@extends('dashboard.master')
@section('content')
    @include('dashboard.layouts.content-header', ['name' => 'cài đặt', 'key' => 'Thêm'])
    <form action="{{ route('settings.store') . '?type=' . request()->type }}" method="post">
        @csrf
        <div class="form-group">
            <label>Cấu hình tên</label>
            <input type="text"
                   class="form-control"
                   name="config_key"
                   placeholder="Nhập tên cài đặt..."
            >
        </div>
        @if(request()->type === 'Text')
            <div class="form-group">
                <label>Cấu hình giá trị</label>
                <input type="text"
                       class="form-control"
                       name="config_value"
                       placeholder="Nhập giá trị..."
                >
            </div>
            @elseif(request()->type === 'Textarea')
            <div class="form-group">
                <label>Cấu hình giá trị</label>
                <textarea
                       class="form-control"
                       name="config_value"
                       placeholder="Nhập config value"
                       rows="5"
                ></textarea>
            </div>

        @endif
        <button type="submit" class="btn btn-primary">Thêm cài đặt</button>
        <button type="button" class="btn btn-info"><a href="{{route('settings.index')}}" style="color: white;text-decoration: none;"> Trở về</a></button>
    </form>
@endsection
