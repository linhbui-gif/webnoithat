
<div class="header">
    <div class="header__info">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="header__info-box">
              <p class="header__info-email"><span><i class="fa fa-envelope"></i><a style="color: white;" href="mailto:{{getConfig('email')}}">{{getConfig('email')}}</a></span>
              </p>
              <p class="header__info-phone"><span> <i class="fa fa-phone"></i><a href="tel:{{getConfig('phone')}}">{{getConfig('phone')}}</a></span></p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="header__menu">
      <div class="container">
        @include('frontend.components.menu.index')
      </div>
    </div>
  </div>