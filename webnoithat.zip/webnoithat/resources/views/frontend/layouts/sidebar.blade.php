<div class="col-12 col-sm-3 col-md-12 col-lg-3">
    <div class="widget">
      <div class="widget__content">
        <h3 class="sidebar-title">Tin tức mới</h3>
        <div class="widget__content-block">
          <ul class="widget__content-box">
              @foreach ($news ?? '' as $newItem)
              <li class="widget__item">
                <a class="widget__item-img" href="{{route('new.detail',['id'=>$newItem->id,'slug'=>$newItem->slug])}}" title="title">
                  <img
                    src="{{$newItem->image_path}}"
                    alt="thiet-ke-noi-that-chung-cu-hien-dai">
                </a>
              <h3 class="widget__item-title"><a href="{{route('new.detail',['id'=>$newItem->id,'slug'=>$newItem->slug])}}" title="title">{{$newItem->title}}</a>
                <div class="widget__item-time">{{$newItem->created_at->format('d/m/Y')}}</div>
              </h3>
            </li>
              @endforeach

          </ul>
        </div>
      </div>
      <div class="widget__fanpage">
        <h3 class="sidebar-title">Fanpage facebook</h3>
        <div class="fanpage"><iframe
          src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FBig-I-Home-Thi%25E1%25BA%25BFt-K%25E1%25BA%25BF-Ki%25E1%25BA%25BFn-Tr%25C3%25BAc-N%25E1%25BB%2599i-Th%25E1%25BA%25A5t-104555761373841%2F&amp;tabs=timeline&amp;width=242&amp;height=210&amp;small_header=false&amp;adapt_container_width=true&amp;hide_cover=false&amp;show_facepile=true&amp;appId=168015681053039"
          width="240" height="210" style="border:none;overflow:hidden" scrolling="no" frameborder="0"
          allowtransparency="true" allow="encrypted-media"></iframe></div>
      </div>
      <div class="widget__social-box">
        <h3 class="sidebar-title">Mạng xã hội</h3>
        <ul class="widget__social mb-3">
          <li class="widget__social-item"><a class="widget__social-link" href="{{getConfig('link-fb')}}"><i
                class="fab fa-facebook-f"></i></a></li>
          <li class="widget__social-item"><a class="widget__social-link" href="{{getConfig('link-fb')}}"><i
                class="fab fa-google"></i></a></li>
          <li class="widget__social-item"><a class="widget__social-link" href="{{getConfig('link-fb')}}"><i
                class="fas fa-envelope"></i></a></li>
          <li class="widget__social-item"><a class="widget__social-link" href="{{getConfig('link-fb')}}"><i class="fab fa-youtube">
              </i></a></li>
        </ul>
      </div>
    </div>
  </div>