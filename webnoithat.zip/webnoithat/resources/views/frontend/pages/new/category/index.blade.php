@extends('frontend.master')
@section('content')
    <div class="posts">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="products__intro">
                        <p class="produScts__intro-content">{{getConfig('text-gioi-thieu')}}</p>
                      </div>
                </div>
                @foreach ($news as $newItem)
                <div class="col-md-6 col-lg-3 mb-2">
                            <a class="card posts__item" href="{{route('new.detail',['id'=>$newItem->id,'slug'=>$newItem->slug])}}"><img
                                    class="card-img-top posts__item-img lazyload" data-original="{{$newItem->image_path}}"
                                    alt="thiet-ke-noi-that-chung-cu">
                                <div class="card-body posts__item-info text-center">
                                    <h5 class="card-title posts__item-title"> {{$newItem->title}}</h5>
                                    <div class="divider"></div>
                                    <p class="card-text">{{$newItem->description}}
                                    </p>
                                </div>
                                {{-- <div class="posts__item-published"><span class="posts__date-day">21</span><br><span
                                        class="posts__date-month">Th08</span></div> --}}
                            </a>
                </div>
                @endforeach
                <div class="posts__pagination">{{$news->links()}}</div>
            </div>
        </div>
    </div>
@endsection
