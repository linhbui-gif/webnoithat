@extends('frontend.master')
@section('content')
<div class="post">
    <div class="container">
      <div class="row">
        <div class="col-12 col-sm-9 col-md-12 col-lg-9">
          <div class="post__body">
            <p>{{$new->category->name}}</p>
            <h1 class="post__title">{{$new->title}}</h1>
            <div class="divider"></div>
            <div class="post__content">
                {!! $new->content !!}
            </div>
            {{-- <div class="post__next">
              <div class="row">
                <div class="col-12 col-sm-6">
                  <p><span>Bài viết trước</span>« <a class="prev" href="#" title="title">{ Hiểu Đúng} Cách Bố Trí
                      Phong Thủy Phòng Khách Chung Cư CHUẨN</a></p>
                </div>
                <div class="col-12 col-sm-6">
                  <p><span>Bài viết sau</span><a class="next" href="#" title="title">Bật Mí 9 Cách Hóa Giải Lỗi Phong
                      Thủy Chung Cư</a> »</p>
                </div>
              </div>
            </div> --}}
            <div class="post__involve">
              <h3 class="post__involve-title">Bài viết nổi bật</h3>
                <div class="row ">
                    @foreach ($newFeatures as $newFeatureItem)
                    <div class="col-12 col-md-4 mb-4">
                        <a class="card posts__item" href="{{route('new.detail',['id'=>$newFeatureItem->id,'slug'=>$newFeatureItem->slug])}}"><img
                            class="card-img-top posts__item-img lazyload"
                            data-original="{{$newFeatureItem->image_path}}"
                            alt="thiet-ke-noi-that-chung-cu-hien-dai">
                        <div class="card-body posts__item-info text-center">
                            <h5 class="card-title posts__item-title">{{$newFeatureItem->title}}</h5>
                            <div class="divider"></div>
                            <p class="card-text">{{$newFeatureItem->description}}</p>
                        </div>
                        {{-- <div class="posts__item-published"><span class="posts__date-day">20</span><br><span
                            class="posts__date-month">Th08</span></div> --}}
                        </a>
                    </div>
                    @endforeach
                </div>
            </div>
          </div>
        </div>
        <!-- Start Sidebar-->
        @include('frontend.layouts.sidebar')
        <!-- End Sidebar-->
      </div>
    </div>
  </div>
@endsection