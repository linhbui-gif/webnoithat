@extends('frontend.master')
@section('content')
    <div class="about">
        <div class="container">
            <div class="row">
                <div class="col-12 col-sm-9">
                    <div class="about__content">
                        {!! $aboutPages->content !!}
                    </div>
                </div>
                <!-- Start Sidebar-->
                @include('frontend.layouts.sidebar')
                <!-- End Sidebar-->
            </div>
        </div>
    </div>
@endsection
