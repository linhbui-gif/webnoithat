<h3>Đăng ký thông tin  thành công</h3>
<a href="{{route('product.index')}}">Trở lại</a>