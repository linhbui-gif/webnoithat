@extends('frontend.master')
@section('content')
    <div class="contact">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="contact__map">
                        <iframe style="border: 0;"
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3724.9887694354293!2d105.81232511429717!3d20.993087294372497!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135ac922c867531%3A0x9bdfdbd6088a56a3!2zMzAzIFbFqSBUw7RuZyBQaGFuLCBLaMawxqFuZyDEkMOsbmgsIFRoYW5oIFh1w6JuLCBIw6AgTuG7mWksIFZp4buHdCBOYW0!5e0!3m2!1svi!2s!4v1574315928638!5m2!1svi!2s"
                            width="100%" height="450" frameborder="0" allowfullscreen=""></iframe>
                    </div>
                </div>
                <div class="col-12 col-sm-6">
                    <div class="contact__form">
                        <h4 class="contact__form-title">Liên hệ với chúng tôi</h4>
                        <form method="POST" action="{{route('customer.store')}}">
                            @csrf
                            <div class="form-style" id="submit-form" data-url="{{ route('customer.store') }}">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Tên của bạn (bắt buộc)</label>
                                    <input class="form-control" id="exampleInputEmail1" type="text" name="name"
                                        aria-describedby="emailHelp" placeholder="Nhập tên của bạn...">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Địa chỉ Email (bắt buộc)</label>
                                    <input class="form-control" id="exampleInputPassword1" type="email" name="email" placeholder="Nhập địa chỉ email...">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Số điện thoại:</label>
                                    <input class="form-control" id="exampleInputEmail1" type="number"
                                        aria-describedby="emailHelp" name="phone" placeholder="Nhập số điện thoại...">
                                </div>
                                <div class="form-group">
                                    <label for="exampleFormControlTextarea1">Thông điệp</label>
                                    <textarea class="form-control" name="content" id="exampleFormControlTextarea1" rows="3"></textarea>
                                </div>
                                <button class="btn btn-primary contact__form-btn" id="submit" type="submit">Gửi đi</button>
                            </div>

                            @include('frontend.layouts.spinner')
                        </form>

                    </div>
                </div>
                <div class="col-12 col-sm-6">
                    <div class="contact__content">
                        {!! $contactPages ? $contactPages->content : '' !!}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('js')
    <script>
        function submitFormCustomer(e) {
            e.preventDefault();
            var formWrapper = $("#submit-form"); // từ cái id mình lấy dc cái div bao quanh f
            // var formWrapper = $(id_cua_form);
            var dataUrl = formWrapper.data('url');
            var _token = $("input[name='_token']").val();
            var name = $("input[name='name']").val();
            var email = $("input[name='email']").val();
            var phone = $("input[name='phone']").val();
            var content = $("#exampleFormControlTextarea1").val();
            $.ajax({
                url: dataUrl,
                type: 'POST',
                data: {
                    _token: _token,
                    name: name,
                    email: email,
                    phone: phone,
                    content: content
                },
                beforeSend: function() {
                    // Show image container
                    $("#loader").show();
                },
                success: function(response) {
                    let dataHtmlSuccess = `
                    <div class="form-group">
                                <label for="exampleInputEmail1">Tên của bạn (bắt buộc)</label>
                                <input class="form-control" id="exampleInputEmail1" type="text" name="name"
                                    aria-describedby="emailHelp" placeholder="Nhập tên của bạn...">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Địa chỉ Email (bắt buộc)</label>
                                <input class="form-control" id="exampleInputPassword1" type="email" name="email" placeholder="Nhập địa chỉ email...">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Số điện thoại:</label>
                                <input class="form-control" id="exampleInputEmail1" type="number"
                                    aria-describedby="emailHelp" name="phone" placeholder="Nhập số điện thoại...">
                            </div>
                            <div class="form-group">
                                <label for="exampleFormControlTextarea1">Thông điệp</label>
                                <textarea class="form-control" name="content" id="exampleFormControlTextarea1" rows="3"></textarea>
                            </div>
                            <button class="btn btn-primary contact__form-btn" id="submit" type="submit">Gửi đi</button>
                            <p style="color: green;
                                margin-top: 20px;
                                padding: 20px 0 20px 10px;
                                background: white;
                                font-weight: 700;">Đăng ký thành công,chúng tôi sẽ liên hệ lại sớm nhất !!</p>`
                    if (response.success === "ok") {
                        formWrapper.html(dataHtmlSuccess)
                    }
                },
                complete: function(data) {
                    $("#loader").hide();
                },
                error: function(error) {

                    let dataErrors = `
                    <div class="form-group">
                                <label for="exampleInputEmail1">Tên của bạn (bắt buộc)</label>
                                <input class="form-control" id="exampleInputEmail1" type="text" name="name"
                                    aria-describedby="emailHelp" placeholder="Nhập tên của bạn...">
                                    <p class="alert alert-danger mt-3">${error.responseJSON.errors.name[0]}</p>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Địa chỉ Email (bắt buộc)</label>
                                <input class="form-control" id="exampleInputPassword1" type="email" name="email" placeholder="Nhập địa chỉ email...">
                                <p class="alert alert-danger mt-3">${error.responseJSON.errors.email[0]}</p>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Số điện thoại:</label>
                                <input class="form-control" id="exampleInputEmail1" type="number"
                                    aria-describedby="emailHelp" name="phone" placeholder="Nhập số điện thoại...">
                                    <p class="alert alert-danger mt-3">${error.responseJSON.errors.phone[0]}</p>
                            </div>
                            <div class="form-group">
                                <label for="exampleFormControlTextarea1">Thông điệp</label>
                                <textarea class="form-control" name="content" id="exampleFormControlTextarea1" rows="3"></textarea>
                                <p class="alert alert-danger mt-3">${error.responseJSON.errors.content[0]}</p>
                            </div>
                            <button class="btn btn-primary contact__form-btn" id="submit" type="submit">Gửi đi</button>
                            <p style="color:red;margin-top: 20px;
                                padding: 20px 0 20px 10px;
                                background: white;
                                font-weight: 700;">Đăng ký thất bại, vui lòng thử lại</p>`
                    formWrapper.html(dataErrors)
                }
            });
        }
        $(function() {
            $("#submit").on('click', submitFormCustomer)
        })

    </script>
@endsection
