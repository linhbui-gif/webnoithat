@extends('frontend.master')
@section('content')
    <!-- Start slider-->
    @include('frontend.components.home.slider')
    <!-- End sliders-->
    <!-- Start service-->
    @include('frontend.components.home.service')
    <!-- End service-->
    <!-- Start banner-->
    @include('frontend.components.home.banner')
    <!-- End banner-->
    <!-- Start product-->
    @include('frontend.components.home.product')
    <!-- End product-->
    <!-- Start Customer-->
    @include('frontend.components.home.customer')
    <!-- End Customer-->
    <!-- Start partner-->
    @include('frontend.components.home.partner')
    <!-- End partner-->

@endsection
