@extends('frontend.master')
@section('content')

    <div class="products__body">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="products__intro">
                        <p class="produScts__intro-content">{{getConfig('text-san-pham')}}</p>
                      </div>
                </div>
                @foreach ($products as $productItem)
                    @if ($productItem)
                        <div class="col-md-6 col-lg-3">
                            <div class="products__item">
                                <div class="products__item-img"><a class="products__item-link" href="{{route('product.detail',['id'=>$productItem->id,'slug'=>$productItem->slug])}}" title="title"><img
                                      class="lazyload"   data-original="{{$productItem->image_path}}"
                                            alt="thiết-kế-nhà-ống-diện-tích-100m2"></a></div>
                                <div class="products__item-info">
                                    <h4 class="products__item-title"><a href="{{route('product.detail',['id'=>$productItem->id,'slug'=>$productItem->slug])}}" title="title">{{$productItem->title}}</a>
                                    </h4>
                                    <ul class="products__item-content">
                                        <li><i class="fas fa-barcode"></i>Mã số CT: {{$productItem->code_ct}}</li>
                                        <li><i class="fas fa-male"></i>Chủ đầu tư:{{$productItem->investor}}</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    @else
                      {{'asdasd'}}
                    @endif
                @endforeach

            </div>
            <div class="products__pagination">
                {{$products->links()}}
            </div>
        </div>
    </div>
@endsection
