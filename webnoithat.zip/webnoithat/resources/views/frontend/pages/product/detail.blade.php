@extends('frontend.master')
@section('content')
    <div class="product-detail">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6">
                    <div class="zoom-area mb-rsp-3"><img id="zoompro"
                    src="{{$product->image_path}}"
                            data-zoom-image="{{$product->image_path}}" alt="zoom"></div>
                </div>
                <div class="col-12 col-md-6">
                    <div class="zoom-product-detail">
                        <div class="zoom-product-detail__breadcrum"><a href="#" title="title">Trang chủ</a>&nbsp;/&nbsp;<a
                                href="{{ route('category.product', ['slug' => $product->category->slug, 'id' => $product->category->id]) }}" title="title">{{$product->category->name}}</a></div>
                        <h2 class="product-detail__title">{{$product->title}}</h2>
                        <div class="divider"></div>
                        <div class="product-detail_meta"><span></span>Danh mục: <a href="{{ route('category.product', ['slug' => $product->category->slug, 'id' => $product->category->id]) }}" title="title">{{$product->category->name}}</a></div>
                        <div class="widget__social-box">
                            <ul class="widget__social mb-3">Chia sẻ:
                                <li class="widget__social-item"><a class="widget__social-link" href="{{getConfig('link-fb')}}"><i
                                            class="fab fa-facebook-f"></i></a></li>
                                <li class="widget__social-item"><a class="widget__social-link" href="{{getConfig('link-fb')}}"><i
                                            class="fab fa-google"></i></a></li>
                                <li class="widget__social-item"><a class="widget__social-link" href="{{getConfig('link-fb')}}"><i
                                            class="fas fa-envelope"></i></a></li>

                                <li class="widget__social-item"><a class="widget__social-link" href="{{getConfig('link-zalo')}}"><svg xmlns="http://www.w3.org/2000/svg" fill="#fff" viewBox="0 0 50 50" width="20px" height="20px"><path d="M 9 4 C 6.2504839 4 4 6.2504839 4 9 L 4 41 C 4 43.749516 6.2504839 46 9 46 L 41 46 C 43.749516 46 46 43.749516 46 41 L 46 9 C 46 6.2504839 43.749516 4 41 4 L 9 4 z M 9 6 L 15.576172 6 C 12.118043 9.5981082 10 14.323627 10 19.5 C 10 24.861353 12.268148 29.748596 15.949219 33.388672 C 15.815412 33.261195 15.988635 33.48288 16.005859 33.875 C 16.023639 34.279773 15.962689 34.835916 15.798828 35.386719 C 15.471108 36.488324 14.785653 37.503741 13.683594 37.871094 A 1.0001 1.0001 0 0 0 13.804688 39.800781 C 16.564391 40.352722 18.51646 39.521812 19.955078 38.861328 C 21.393696 38.200845 22.171033 37.756375 23.625 38.34375 A 1.0001 1.0001 0 0 0 23.636719 38.347656 C 26.359037 39.41176 29.356235 40 32.5 40 C 36.69732 40 40.631169 38.95117 44 37.123047 L 44 41 C 44 42.668484 42.668484 44 41 44 L 9 44 C 7.3315161 44 6 42.668484 6 41 L 6 9 C 6 7.3315161 7.3315161 6 9 6 z M 18.496094 6 L 41 6 C 42.668484 6 44 7.3315161 44 9 L 44 34.804688 C 40.72689 36.812719 36.774644 38 32.5 38 C 29.610147 38 26.863646 37.459407 24.375 36.488281 C 22.261967 35.634656 20.540725 36.391201 19.121094 37.042969 C 18.352251 37.395952 17.593707 37.689389 16.736328 37.851562 C 17.160501 37.246758 17.523335 36.600775 17.714844 35.957031 C 17.941109 35.196459 18.033096 34.45168 18.003906 33.787109 C 17.974816 33.12484 17.916946 32.518297 17.357422 31.96875 L 17.355469 31.966797 C 14.016928 28.665356 12 24.298743 12 19.5 C 12 14.177406 14.48618 9.3876296 18.496094 6 z M 32.984375 14.986328 A 1.0001 1.0001 0 0 0 32 16 L 32 25 A 1.0001 1.0001 0 1 0 34 25 L 34 16 A 1.0001 1.0001 0 0 0 32.984375 14.986328 z M 18 16 A 1.0001 1.0001 0 1 0 18 18 L 21.197266 18 L 17.152344 24.470703 A 1.0001 1.0001 0 0 0 18 26 L 23 26 A 1.0001 1.0001 0 1 0 23 24 L 19.802734 24 L 23.847656 17.529297 A 1.0001 1.0001 0 0 0 23 16 L 18 16 z M 29.984375 18.986328 A 1.0001 1.0001 0 0 0 29.162109 19.443359 C 28.664523 19.170123 28.103459 19 27.5 19 C 25.578848 19 24 20.578848 24 22.5 C 24 24.421152 25.578848 26 27.5 26 C 28.10285 26 28.662926 25.829365 29.160156 25.556641 A 1.0001 1.0001 0 0 0 31 25 L 31 22.5 L 31 20 A 1.0001 1.0001 0 0 0 29.984375 18.986328 z M 38.5 19 C 36.578848 19 35 20.578848 35 22.5 C 35 24.421152 36.578848 26 38.5 26 C 40.421152 26 42 24.421152 42 22.5 C 42 20.578848 40.421152 19 38.5 19 z M 27.5 21 C 28.340272 21 29 21.659728 29 22.5 C 29 23.340272 28.340272 24 27.5 24 C 26.659728 24 26 23.340272 26 22.5 C 26 21.659728 26.659728 21 27.5 21 z M 38.5 21 C 39.340272 21 40 21.659728 40 22.5 C 40 23.340272 39.340272 24 38.5 24 C 37.659728 24 37 23.340272 37 22.5 C 37 21.659728 37.659728 21 38.5 21 z"/></svg></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="product-detail__tablist">
                        <ul class="tablist">
                            <li class="tablist__item"><a class="class" href="#">Mô tả</a></li>
                        </ul>
                        <div class="product-detail__content">
                             {!! $product->content !!}
                        </div>
                    </div>
                    <h4>Gửi yêu cầu tư vấn</h4>
                    <div class="product-detail__form">
                        <form method="POST" action="{{route('customer.store')}}" >
                            @csrf
                            <div class="contact-form row" id="submit-detail-form" data-url="{{ route('customer.store') }}">
                                <div class="contact-form__left col-12 col-sm-6"><span>
                                        <input type="text" name="name" placeholder="Họ tên"></span><span class="icon"><i
                                            class="fas fa-user"></i></span><span>

                                        <input type="tel" name="phone" placeholder="Số điện thoại"></span><span
                                        class="icon"><i class="fas fa-phone-square-alt"></i></span><span>
                                        <input type="email" name="email" placeholder="Email"></span><span class="icon"><i
                                            class="far fa-envelope"></i></span></div>
                                <div class="contact-form__right col-12 col-sm-6"><span>
                                        <textarea name="content" cols="40" rows="10" placeholder="Nội dung" id="contentdetail"></textarea></span>
                                    <button type="submit" id="submitDetail">Gửi câu hỏi</button>
                                </div>
                            </div>
                            @include('frontend.layouts.spinner')
                        </form>
                    </div>
                    <div class="product-detail__related">
                        <h3 class="title">sản phẩm nổi bật</h3>
                        <div class="row">
                            @foreach ($productRelated as $productRelatedItem)
                            <div class="col-lg-3 col-md-6">
                                <div class="products__item">
                                    <div class="products__item-img"><a class="products__item-link" href="{{route('product.detail',['id'=>$productRelatedItem->id,'slug'=>$productRelatedItem->slug])}}"
                                            title="title"><img class="lazyload" data-original="{{$productRelatedItem->image_path}}"
                                                alt="thiết-kế-nhà-ống-diện-tích-100m2"></a></div>
                                    <div class="products__item-info">
                                        <h4 class="products__item-title"><a href="{{route('product.detail',['id'=>$productRelatedItem->id,'slug'=>$productRelatedItem->slug])}}" title="title">{{$productRelatedItem->title}}</a></h4>
                                        <ul class="products__item-content">
                                            <li><i class="fas fa-barcode"></i>Mã số CT: {{$productRelatedItem->code_ct}}</li>
                                            <li><i class="fas fa-male"></i>Chủ đầu tư: {{$productRelatedItem->investor}}</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            @endforeach

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('js')
    <script>
        function submitFormCustomer(e) {
            e.preventDefault();
            var formWrapper = $("#submit-detail-form"); // từ cái id mình lấy dc cái div bao quanh f
            // var formWrapper = $(id_cua_form);
            var dataUrl = formWrapper.data('url');
            var _token = $("input[name='_token']").val();
            var name = $("input[name='name']").val();
            var email = $("input[name='email']").val();
            var phone = $("input[name='phone']").val();
            var content = $("#contentdetail").val();
            $.ajax({
                url: dataUrl,
                type: 'POST',
                data: {
                    _token: _token,
                    name: name,
                    email: email,
                    phone: phone,
                    content: content
                },
                beforeSend: function() {
                    // Show image container
                    $("#loader").show();
                },
                success: function(response) {
                    let dataHtmlSuccess = `
                    <div class="contact-form__left col-12 col-sm-6"><span>
                                        <input type="text" name="name" placeholder="Họ tên"></span><span class="icon"><i
                                            class="fas fa-user"></i></span><span>

                                        <input type="tel" name="phone" placeholder="Số điện thoại"></span><span
                                        class="icon"><i class="fas fa-phone-square-alt"></i></span><span>
                                        <input type="email" name="email" placeholder="Email"></span><span class="icon"><i
                                            class="far fa-envelope"></i></span></div>
                                <div class="contact-form__right col-12 col-sm-6"><span>
                                        <textarea name="content" cols="40" rows="10" placeholder="Nội dung" id="contentdetail"></textarea></span>
                                    <button type="submit">Gửi câu hỏi</button>
                                </div>
                            <p style="color: green;
                                margin-top: 20px;
                                padding: 20px 10px 20px 10px;
                                margin-left:15px;
                                background: white;
                                font-weight: 700;">Gửi yêu cầu thành công,chúng tôi sẽ liên hệ lại sớm nhất !!</p>`
                    if (response.success === "ok") {
                        formWrapper.html(dataHtmlSuccess)
                    }
                },
                complete: function(data) {
                    $("#loader").hide();
                },
                error: function(error) {

                    let dataErrors = `
                    <div class="contact-form__left col-12 col-sm-6"><span>
                                        <input type="text" name="name" placeholder="Họ tên"></span><span class="icon"><i
                                            class="fas fa-user"></i></span><span>
                                         <p class=" mt-1" style="color:red;font-weight: 700;">${error.responseJSON.errors.name[0]}</p>
                                        <input type="tel" name="phone" placeholder="Số điện thoại"></span><span
                                        class="icon"><i class="fas fa-phone-square-alt"></i></span><span>
                                        <p class=" mt-1" style="color:red;font-weight: 700;">${error.responseJSON.errors.phone[0]}</p>
                                        <input type="email" name="email" placeholder="Email"></span><span class="icon"><i
                                            class="far fa-envelope"></i></span>
                                            <p class=" mt-1" style="color:red;font-weight: 700;">${error.responseJSON.errors.email[0]}</p>
                                            </div>
                                <div class="contact-form__right col-12 col-sm-6"><span>
                                        <textarea name="content" cols="40" rows="10" placeholder="Nội dung" id="contentdetail"></textarea> <p class=" mt-1" style="color:red;font-weight: 700;">${error.responseJSON.errors.content[0]}</p></span>

                                    <button type="submit">Gửi câu hỏi</button>
                                </div>
                            <p style="color:green;margin-top: 20px;
                                padding: 20px 20px 20px 10px;
                                background: white;
                                margin-left:15px;
                                font-weight: 700;">Gửi yêu cầu thất bại, vui lòng thử lại</p>`
                    formWrapper.html(dataErrors)
                }
            });
        }
        $(function() {
            $("#submitDetail").on('click', submitFormCustomer)
        })

    </script>
@endsection
