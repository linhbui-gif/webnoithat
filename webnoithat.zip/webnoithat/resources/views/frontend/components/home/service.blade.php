<div class="services section">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <h2 class="services__title title">Dịch vụ & sản phẩm của chúng tôi dành cho ai?</h2>
        </div>
        @foreach ($serviceUps as $serviceItem)
          <div class="col-md-6 col-lg-3">
            <div class="services__item">
            <div class="services__item-img"><img class="img-fluid lazyload"  data-original="{{$serviceItem->image_path}}" alt="service"></div>
              <div class="services__item-content">
                <p>{{$serviceItem->content}}</p>
              </div>
            </div>
          </div>
        @endforeach

        <div class="col-12">
          <h2 class="services__title title">Tại sao bạn nên chọn chúng tôi ??? </h2>
        </div>
        @foreach ($serviceDowns as $serviceDownItem)
        <div class="col-md-6 col-lg-3">
          <div class="services__item">
            <div class="services__item-img"><img class="img-fluid lazyload" data-original="{{$serviceDownItem->image_path}}" alt="service"></div>
            <div class="services__item-content">
              <p>{{$serviceDownItem->content}}</p>
            </div>
          </div>
        </div>
        @endforeach
      </div>
    </div>
  </div>