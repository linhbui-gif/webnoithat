<div class="slider owl-carousel owl-theme">
    @foreach ($sliders as $sliderItem)
        <div class="slider__item"><img src="{{$sliderItem->image_path}}" alt="slider-img" title="#caption1">

            <div class="slider__item-text"  style="width:100%;">

                    <div class="row">
                        <div class="col-8">
                                <h1 style="color: white;"><span>{{$sliderItem->title}}</span></h1>
                                <p style="color: white">{{$sliderItem->description}}</p>
                                <div class="btn btn-primary">
                                <a style="color: white;" href="{{getConfig('button-xem-them-slider')}}">Xem Thêm</a>
                                </div>

                        </div>
                    </div>

            </div>
        </div>
    @endforeach
  </div>