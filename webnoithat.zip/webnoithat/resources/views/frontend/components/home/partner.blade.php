<div class="partner">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <h2 class="partner__title title">AN CƯỜNG HÂN HẠNH ĐỒNG HÀNH CÙNG ĐỐI TÁC</h2>
          <div class="partner__box owl-carousel owl-theme">
            @foreach ($partners as $partnerItem)
               <div class="partner__item"><img class="lazyload" data-original="{{$partnerItem->image_path}}" alt="đối tác"></div>
            @endforeach
          </div>
        </div>
      </div>
    </div>
  </div>