<div class="banner" style="background: url('{{$banner->image_path}}')">
    <div class="container">
      <div class="banner__title d-flex  flex-wrap" id="banner__title">
        <h3>{{$banner->title}}</h3>
        <button class="btn btn-primary">
        <a href="{{getConfig('link-banner')}}" class="btn__button" style="color: white;">Xem thêm</a>
        </button>
      </div>
    </div>
  </div>