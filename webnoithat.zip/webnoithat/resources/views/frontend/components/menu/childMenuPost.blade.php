@if ($postCategoryItemParent->categoryChildrent->count())
        <ul class="sub-menu">
            @foreach ($postCategoryItemParent->categoryChildrent as $categoryChild)
                <li class="sub-menu__item">
                    <a class="sub-menu__link" href="{{route('category-new.new',['slug'=>$categoryChild->slug,'id'=>$categoryChild->id])}}">{{$categoryChild->name}}</a>
                    @if ($categoryChild->categoryChildrent->count())
                       @include('frontend.components.menu.childMenuPost',['postCategoryItemParent'=>$categoryChild])
                    @endif
                </li>
            @endforeach
        </ul>
@endif