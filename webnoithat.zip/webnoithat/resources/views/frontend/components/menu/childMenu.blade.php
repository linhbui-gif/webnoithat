@if ($categoryParent->categoryChildrent->count())
        <ul class="sub-menu">
            @foreach ($categoryParent->categoryChildrent as $categoryChild)
                <li class="sub-menu__item">
                    <a class="sub-menu__link" href="{{route('category.product',['slug'=>$categoryChild->slug,'id'=>$categoryChild->id])}}">{{$categoryChild->name}}</a>
                    @if ($categoryChild->categoryChildrent->count())
                       @include('frontend.components.menu.childMenu',['categoryParent'=>$categoryChild])
                    @endif
                </li>
            @endforeach
        </ul>
@endif