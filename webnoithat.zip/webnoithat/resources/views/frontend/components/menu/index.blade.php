<div class="header__menu-box">
    <ul class="header__menu-main header__menu-left">
        @foreach ($categories as $categoryParent)
            <li class="header__menu-item"><a class="header__menu-link"
                    href="{{ route('category.product', ['slug' => $categoryParent->slug, 'id' => $categoryParent->id]) }}"
                    title="title">{{ $categoryParent->name }}<i class="fas fa-sort-down"></i></a>
                @include('frontend.components.menu.childMenu',['categoryParent'=>$categoryParent])
            </li>
        @endforeach
    </ul>
    <a class="header__logo" href="/" title="title"><img src="{{ $logo->image_path }}"
            alt="logo"></a><a class="header__menu-bar-button" href="#"><i class="fas fa-bars"></i></a>
    <div class="header__menu-right-box">
        <ul class="header__menu-main header__menu-right d-flex">
            @foreach ($postCategories as $postCategoryItemParent)
            <li class="header__menu-item"><a class="header__menu-link" href="{{ route('new.index') }}"
                title="title">{{$postCategoryItemParent->name}}<i class="fas fa-sort-down"></i></a>
                @include('frontend.components.menu.childMenuPost',['postCategoryItemParent'=>$postCategoryItemParent])
            </li>

            @endforeach

            <li class="header__menu-item"><a class="header__menu-link" href="#" title="title">về an cường<i
                        class="fas fa-sort-down"></i></a>
                <ul class="sub-menu">
                    <li class="sub-menu__item"><a class="sub-menu__link" href="{{ route('about.index') }}">tổng quan về
                            an cường</a></li>
                    <li class="sub-menu__item"><a class="sub-menu__link" href="{{ route('contact.index') }}">liên hệ</a>
                    </li>
                </ul>
            </li>
        </ul>
        <div class="header__menu-search">
            <form class="search-form" role="search" method="get" action="">
                <input class="search-field" type="search" placeholder="Tìm công trình..." value="" name="s">
                <button class="btn-search" type="submit"><i class="fa fa-search"></i></button>
                <input type="hidden" name="post_type" value="product">
            </form>
        </div>
    </div>
    <ul class="header__menu-mobile">
        @foreach ($categories as $categoryParent)
            <li class="header__menu-mobile-item"><a class="header__menu-mobile-link"
                    href="{{ route('category.product', ['slug' => $categoryParent->slug, 'id' => $categoryParent->id]) }}"
                    title="title">{{ $categoryParent->name }}<i class="fas fa-sort-down"></i></a>
                @include('frontend.components.menu.childMenu',['categoryParent'=>$categoryParent])
            </li>
        @endforeach

        <li class="header__menu-mobile-item"><a class="header__menu-mobile-link" href="{{ route('product.index') }}"
                title="title">Sản phẩm</a>
        </li>
        <li class="header__menu-mobile-item"><a class="header__menu-mobile-link" href="{{ route('new.index') }}"
                title="title">kiến thức nhà đẹp</a></li>
        <li class="header__menu-mobile-item"><a class="header__menu-mobile-link" href="#" title="title">về an
                cường<i class="fas fa-sort-down"></i></a>
            <ul class="sub-menu">
                <li class="sub-menu__item"><a class="sub-menu__link" href="{{ route('about.index') }}">tổng quan về an
                        cường</a></li>
                <li class="sub-menu__item"><a class="sub-menu__link" href="{{ route('contact.index') }}">liên hệ</a>
                </li>
            </ul>
        </li>
    </ul>
</div>
