Create shorthand migration,model,controller
php artisan make:model -mc AdminPost_categories
Create  table migration
php artisan make:migration create_customers_table --create=customers
Add new column to table migration
php artisan make:migration add_features_to_admin_partner_table --table=admin_partner
Install helper
composer require laravel/helpers
Sweet alert
composer require realrashid/sweet-alert
php artisan sweetalert:publish
Tutorial : https://realrashid.github.io/sweet-alert/config
Create Request validation
php artisan make:request HomeRequest


install tinyMCE
https://github.com/UniSharp/laravel-filemanager
File manager config
 - Step 1
   + composer require unisharp/laravel-filemanager
   + php artisan vendor:publish --tag=lfm_config
   + php artisan vendor:publish --tag=lfm_public
   + php artisan storage:link
 - Step 2
   + Edit config/app.php :
   + Add service providers
   + UniSharp\LaravelFilemanager\LaravelFilemanagerServiceProvider::class,
    Intervention\Image\ImageServiceProvider::class,
   + And add class aliases  'Image' => Intervention\Image\Facades\Image::class,
 - Step 3
   + php artisan route:clear
   + php artisan config:clear
   + php artisan route:list
Setup to project
  https://unisharp.github.io/laravel-filemanager/integration