<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/login', 'AdminAuthController@loginAdmin');
Route::post('/login', 'AdminAuthController@postLoginAdmin');
Route::get('/logout', 'AdminAuthController@logoutAdmin');
Route::group(['prefix'=>'dashboard','middleware'=>'adminLogin'],function () {
    Route::get('/', 'AdminDashboardController@index');
    Route::prefix('menus')->group(function () {
        Route::get('/create', [
           'as' => 'menus.create',
           'uses' => 'AdminMenuController@create'
        ]);
        Route::get('/', [
           'as' => 'menus.index',
           'uses' => 'AdminMenuController@index'
        ]);
        Route::post('/store', [
            'as' => 'menus.store',
            'uses' => 'AdminMenuController@store'
         ]);
         Route::get('/edit/{id}', [
            'as' => 'menus.edit',
            'uses' => 'AdminMenuController@edit'
         ]);
         Route::post('/update/{id}', [
            'as' => 'menus.update',
            'uses' => 'AdminMenuController@update'
         ]);
         Route::get('/delete/{id}', [
            'as' => 'menus.delete',
            'uses' => 'AdminMenuController@delete'
         ]);
    });
    Route::prefix('settings')->group(function () {
        Route::get('/create', [
           'as' => 'settings.create',
           'uses' => 'AdminSettingController@create'
        ]);
        Route::get('/', [
           'as' => 'settings.index',
           'uses' => 'AdminSettingController@index'
        ]);
        Route::post('/store', [
            'as' => 'settings.store',
            'uses' => 'AdminSettingController@store'
         ]);
         Route::get('/edit/{id}', [
            'as' => 'settings.edit',
            'uses' => 'AdminSettingController@edit'
         ]);
         Route::post('/update/{id}', [
            'as' => 'settings.update',
            'uses' => 'AdminSettingController@update'
         ]);
         Route::get('/delete/{id}', [
            'as' => 'settings.delete',
            'uses' => 'AdminSettingController@delete'
         ]);
    });
    Route::prefix('sliders')->group(function () {
        Route::get('/create', [
           'as' => 'sliders.create',
           'uses' => 'AdminSliderController@create'
        ]);
        Route::get('/', [
           'as' => 'sliders.index',
           'uses' => 'AdminSliderController@index'
        ]);
        Route::post('/store', [
            'as' => 'sliders.store',
            'uses' => 'AdminSliderController@store'
         ]);
         Route::get('/edit/{id}', [
            'as' => 'sliders.edit',
            'uses' => 'AdminSliderController@edit'
         ]);
         Route::post('/update/{id}', [
            'as' => 'sliders.update',
            'uses' => 'AdminSliderController@update'
         ]);
         Route::get('/delete/{id}', [
            'as' => 'sliders.delete',
            'uses' => 'AdminSliderController@delete'
         ]);
    });
    Route::prefix('services')->group(function () {
        Route::get('/create', [
           'as' => 'services.create',
           'uses' => 'AdminServiceController@create'
        ]);
        Route::get('/', [
           'as' => 'services.index',
           'uses' => 'AdminServiceController@index'
        ]);
        Route::post('/store', [
            'as' => 'services.store',
            'uses' => 'AdminServiceController@store'
         ]);
         Route::get('/edit/{id}', [
            'as' => 'services.edit',
            'uses' => 'AdminServiceController@edit'
         ]);
         Route::post('/update/{id}', [
            'as' => 'services.update',
            'uses' => 'AdminServiceController@update'
         ]);
         Route::get('/delete/{id}', [
            'as' => 'services.delete',
            'uses' => 'AdminServiceController@delete'
         ]);
    });
    Route::prefix('clients')->group(function () {
        Route::get('/create', [
           'as' => 'clients.create',
           'uses' => 'AdminClientController@create'
        ]);
        Route::get('/', [
           'as' => 'clients.index',
           'uses' => 'AdminClientController@index'
        ]);
        Route::post('/store', [
            'as' => 'clients.store',
            'uses' => 'AdminClientController@store'
         ]);
         Route::get('/edit/{id}', [
            'as' => 'clients.edit',
            'uses' => 'AdminClientController@edit'
         ]);
         Route::post('/update/{id}', [
            'as' => 'clients.update',
            'uses' => 'AdminClientController@update'
         ]);
         Route::get('/delete/{id}', [
            'as' => 'clients.delete',
            'uses' => 'AdminClientController@delete'
         ]);
    });
    Route::prefix('partners')->group(function () {
        Route::get('/create', [
           'as' => 'partners.create',
           'uses' => 'AdminPartnerController@create'
        ]);
        Route::get('/', [
           'as' => 'partners.index',
           'uses' => 'AdminPartnerController@index'
        ]);
        Route::post('/store', [
            'as' => 'partners.store',
            'uses' => 'AdminPartnerController@store'
         ]);
         Route::get('/edit/{id}', [
            'as' => 'partners.edit',
            'uses' => 'AdminPartnerController@edit'
         ]);
         Route::post('/update/{id}', [
            'as' => 'partners.update',
            'uses' => 'AdminPartnerController@update'
         ]);
         Route::get('/delete/{id}', [
            'as' => 'partners.delete',
            'uses' => 'AdminPartnerController@delete'
         ]);
    });
    Route::prefix('news')->group(function () {
        Route::get('/create', [
           'as' => 'news.create',
           'uses' => 'AdminNewController@create'
        ]);
        Route::get('/', [
           'as' => 'news.index',
           'uses' => 'AdminNewController@index'
        ]);
        Route::post('/store', [
            'as' => 'news.store',
            'uses' => 'AdminNewController@store'
         ]);
         Route::get('/edit/{id}', [
            'as' => 'news.edit',
            'uses' => 'AdminNewController@edit'
         ]);
         Route::post('/update/{id}', [
            'as' => 'news.update',
            'uses' => 'AdminNewController@update'
         ]);
         Route::get('/delete/{id}', [
            'as' => 'news.delete',
            'uses' => 'AdminNewController@delete'
         ]);
    });
    Route::prefix('newCate')->group(function () {
        Route::get('/create', [
           'as' => 'newCate.create',
           'uses' => 'AdminPostCategoriesController@create'
        ]);
        Route::get('/', [
           'as' => 'newCate.index',
           'uses' => 'AdminPostCategoriesController@index'
        ]);
        Route::post('/store', [
            'as' => 'newCate.store',
            'uses' => 'AdminPostCategoriesController@store'
         ]);
         Route::get('/edit/{id}', [
            'as' => 'newCate.edit',
            'uses' => 'AdminPostCategoriesController@edit'
         ]);
         Route::post('/update/{id}', [
            'as' => 'newCate.update',
            'uses' => 'AdminPostCategoriesController@update'
         ]);
         Route::get('/delete/{id}', [
            'as' => 'newCate.delete',
            'uses' => 'AdminPostCategoriesController@delete'
         ]);
    });
    Route::prefix('products')->group(function () {
        Route::get('/create', [
           'as' => 'products.create',
           'uses' => 'AdminProductController@create'
        ]);
        Route::get('/', [
           'as' => 'products.index',
           'uses' => 'AdminProductController@index'
        ]);
        Route::post('/store', [
            'as' => 'products.store',
            'uses' => 'AdminProductController@store'
         ]);
         Route::get('/edit/{id}', [
            'as' => 'products.edit',
            'uses' => 'AdminProductController@edit'
         ]);
         Route::post('/update/{id}', [
            'as' => 'products.update',
            'uses' => 'AdminProductController@update'
         ]);
         Route::get('/delete/{id}', [
            'as' => 'products.delete',
            'uses' => 'AdminProductController@delete'
         ]);
    });
    Route::prefix('product-categories')->group(function () {
        Route::get('/create', [
           'as' => 'product-categories.create',
           'uses' => 'AdminProductCategorieController@create'
        ]);
        Route::get('/', [
           'as' => 'product-categories.index',
           'uses' => 'AdminProductCategorieController@index'
        ]);
        Route::post('/store', [
            'as' => 'product-categories.store',
            'uses' => 'AdminProductCategorieController@store'
         ]);
         Route::get('/edit/{id}', [
            'as' => 'product-categories.edit',
            'uses' => 'AdminProductCategorieController@edit'
         ]);
         Route::post('/update/{id}', [
            'as' => 'product-categories.update',
            'uses' => 'AdminProductCategorieController@update'
         ]);
         Route::get('/delete/{id}', [
            'as' => 'product-categories.delete',
            'uses' => 'AdminProductCategorieController@delete'
         ]);
    });
    Route::prefix('users')->group(function () {
        Route::get('/create', [
           'as' => 'users.create',
           'uses' => 'AdminUserController@create'
        ]);
        Route::get('/', [
           'as' => 'users.index',
           'uses' => 'AdminUserController@index'
        ]);
        Route::post('/store', [
            'as' => 'users.store',
            'uses' => 'AdminUserController@store'
         ]);
         Route::get('/edit/{id}', [
            'as' => 'users.edit',
            'uses' => 'AdminUserController@edit'
         ]);
         Route::post('/update/{id}', [
            'as' => 'users.update',
            'uses' => 'AdminUserController@update'
         ]);
         Route::get('/delete/{id}', [
            'as' => 'users.delete',
            'uses' => 'AdminUserController@delete'
         ]);
    });
    Route::prefix('profile')->group(function () {
        Route::get('/{id}', [
           'as' => 'profile.detail',
           'uses' => 'AdminProfileController@detail'
        ]);
    });
    Route::prefix('customers')->group(function () {
        Route::get('/{id}', [
           'as' => 'customers.detail',
           'uses' => 'AdminCustomerController@detail'
        ]);
        Route::get('/', [
           'as' => 'customers.index',
           'uses' => 'AdminCustomerController@index'
        ]);
        Route::get('/delete/{id}', [
         'as' => 'customers.delete',
         'uses' => 'AdminCustomerController@delete'
      ]);
    });
    Route::prefix('pages')->group(function () {
      Route::get('/create', [
         'as' => 'pages.create',
         'uses' => 'AdminPageController@create'
      ]);
      Route::get('/', [
         'as' => 'pages.index',
         'uses' => 'AdminPageController@index'
      ]);
      Route::post('/store', [
          'as' => 'pages.store',
          'uses' => 'AdminPageController@store'
       ]);
       Route::get('/edit/{id}', [
          'as' => 'pages.edit',
          'uses' => 'AdminPageController@edit'
       ]);
       Route::post('/update/{id}', [
          'as' => 'pages.update',
          'uses' => 'AdminPageController@update'
       ]);
       Route::get('/delete/{id}', [
          'as' => 'pages.delete',
          'uses' => 'AdminPageController@delete'
       ]);
    });
});
Route::group(['prefix'=>'/'],function () {
   Route::get('/', 'HomePagesController@index');
   Route::post('/store', 'HomePagesController@store')->name('form.store');
   Route::prefix('product')->group(function () {
      Route::get('/', [
         'as' => 'product.index',
         'uses' => 'ProductController@index'
      ]);
       Route::get('detail/{id}/{slug}', [
          'as' => 'product.detail',
          'uses' => 'ProductController@detail'
       ]);
   });
   Route::prefix('new')->group(function () {
      Route::get('/', [
         'as' => 'new.index',
         'uses' => 'NewsController@index'
      ]);
       Route::get('detail/{id}/{slug}', [
          'as' => 'new.detail',
          'uses' => 'NewsController@detail'
       ]);
   });
   Route::get('category-new/{slug}/{id}', [
      'as' => 'category-new.new',
      'uses' => 'CategoryPostController@index'
   ]);
   Route::prefix('about')->group(function () {
      Route::get('/', [
         'as' => 'about.index',
         'uses' => 'AboutController@index'
      ]);
   });
   Route::prefix('contact')->group(function () {
      Route::get('/', [
         'as' => 'contact.index',
         'uses' => 'ContactController@index'
      ]);
   });
   Route::prefix('customer')->group(function () {
      Route::post('/store', [
         'as' => 'customer.store',
         'uses' => 'CustomersController@store'
      ]);
   });
   Route::get('category/{slug}/{id}', [
      'as' => 'category.product',
      'uses' => 'CategoryController@index'
   ]);
});