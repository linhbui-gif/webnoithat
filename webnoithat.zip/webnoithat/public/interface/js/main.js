$(function() {
	$('img.lazyload').lazyload({
		effect : 'fadeIn'
	});
	// owlCarousel slider customer
	$('.slider').owlCarousel({
		loop       : true,
		dots       : true,
		nav        : true,
		autoplay   : true,
		responsive : {
			0    : {
				items : 1
			},
			600  : {
				items : 1
			},
			1000 : {
				items : 1
			}
		}
	});
	// owlCarousel slider product
	$('.products__box').owlCarousel({
		loop       : false,
		dots       : false,
		nav        : true,
		autoplay   : true,
		responsive : {
			0    : {
				items : 1
			},
			600  : {
				items : 2
			},
			1000 : {
				items  : 4,
				margin : 30
			}
		}
	});

	// owlCarousel slider customer
	$('.customer__box').owlCarousel({
		loop       : false,
		dots       : false,
		autoplay   : true,
		responsive : {
			0    : {
				items : 1
			},
			600  : {
				items : 2
			},
			1000 : {
				items  : 4,
				margin : 30
			}
		}
	});

	// owlCarousel slider partner
	$('.partner__box').owlCarousel({
		loop       : false,
		dots       : false,
		autoplay   : true,
		responsive : {
			0    : {
				items : 1
			},
			600  : {
				items : 3
			},
			1000 : {
				items  : 5,
				margin : 20
			}
		}
	});

	function ts_browserWidth() {
		return $(window).width();
	}

	/*****
 * "Back to top" button
 *****/
	if ($('#ts-back-to-top').length) {
		$(window).scroll(function() {
			if (ts_browserWidth() >= 720 || $('body').hasClass('ts-back-to-top-mobile')) {
				if ($(window).scrollTop() >= 500) {
					$('#ts-back-to-top').addClass('hello');
				}
				else {
					$('#ts-back-to-top').removeClass('hello');
				}
			}
		});
	}

	/*--------------------------
		 Zoom
		---------------------------- */
	$('#zoompro').elevateZoom({
		gallery            : 'gallery',
		galleryActiveClass : 'active',
		zoomWindowWidth    : 300,
		zoomWindowHeight   : 100,
		scrollZoom         : false,
		zoomType           : 'inner'
	});

	const buttonBar = document.querySelector('.header__menu-bar-button');
	const menuMobile = document.querySelector('.header__menu-mobile');

	buttonBar.addEventListener('click', function() {
		menuMobile.classList.toggle('show');
	});

	const menuMobileLinkBtn = document.querySelectorAll('.header__menu-mobile-item i');
	Array.from(menuMobileLinkBtn).forEach(item => {
		item.addEventListener('click', function(e) {
			e.preventDefault();
			this.classList.toggle('active');
			this.parentElement.nextElementSibling.classList.toggle('show');
			this.parentElement.classList.toggle('active');
		});
	});
});

// $(document).ready(function() {
// 	var t = { delay: 125, overlay: $('.fb-overlay'), widget: $('.fb-widget'), button: $('.fb-button') };
// 	setTimeout(function() {
// 		$('div.fb-livechat').fadeIn();
// 	}, 8 * t.delay),
// 		$('.ctrlq').on('click', function(e) {
// 			e.preventDefault(),
// 				t.overlay.is(':visible')
// 					? (t.overlay.fadeOut(t.delay),
// 						t.widget.stop().animate({ bottom: 0, opacity: 0 }, 2 * t.delay, function() {
// 							$(this).hide('slow'), t.button.show();
// 						}))
// 					: t.button.fadeOut('medium', function() {
// 							t.widget.stop().show().animate({ bottom: '30px', opacity: 1 }, 2 * t.delay), t.overlay.fadeIn(t.delay);
// 						});
// 		});
// });
