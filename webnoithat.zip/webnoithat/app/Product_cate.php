<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Product_cate extends Model
{
    use SoftDeletes;
    protected $guarded = [];
    protected $table = "product_cates";
}
