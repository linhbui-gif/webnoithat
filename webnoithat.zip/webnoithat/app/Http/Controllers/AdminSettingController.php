<?php

namespace App\Http\Controllers;

use App\AdminSetting;
use App\Traits\DeleteModelTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class AdminSettingController extends Controller
{
    use DeleteModelTrait;
    private $setting;
    public function __construct(AdminSetting $setting)
    {
          $this->setting = $setting;
    }
    public function index(){
        $settings = $this->setting->latest()->paginate(5);
        return view('dashboard.pages.settings.index', compact('settings'));
    }
    public function create()
    {
        return view('dashboard.pages.settings.add');
    }
    public function store(Request $request)
    {
        try {
            $dataInsert = [
                'config_key' => $request->config_key,
                'config_value' => $request->config_value,
                'type' => $request->type
            ];
            $result = $this->setting->create($dataInsert);
            if($result){
                toast('Thêm mới cấu hình thành công','success','top-right');
            }
            else{
                toast('Thêm mới cấu hình không thành công','error','top-right');
            }
            return redirect()->route('settings.index');
        } catch (\Exception $exception) {
            Log::error('Lỗi : ' . $exception->getMessage() . '---Line: ' . $exception->getLine());
        }
    }
    public function edit($id)
    {
        $setting = $this->setting->find($id);
        return view('dashboard.pages.settings.edit', compact('setting'));
    }

    public function update(Request $request, $id)
    {
        $this->setting->find($id)->update([
            'config_key' => $request->config_key,
            'config_value' => $request->config_value
        ]);
        return redirect()->route('settings.index');
    }

    public function delete($id)
    {
        $result = $this->deleteModelTrait($id, $this->setting);
        if($result){
                toast('Xóa cài đặt thành công','success','top-right');
        }
        else{
            toast('Xóa cài đặt không thành công','error','top-right');
        }
        return redirect()->route('settings.index');
    }
}
