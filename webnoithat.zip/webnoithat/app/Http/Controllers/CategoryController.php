<?php

namespace App\Http\Controllers;

use App\AdminPartner;
use App\AdminPost_categories;
use App\AdminProduct;
use App\AdminProduct_categories;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    private $category,$partner,$product,$postCategories;
    public function __construct(AdminPartner $partner,AdminProduct_categories $category,AdminProduct $product,AdminPost_categories $postCategories)
    {
        $this->category = $category;
        $this->product = $product;
        $this->postCategories = $postCategories;
        $this->partner = $partner;
    }
    public function index($slug,$id_cate){
        $categories = $this->category->where('parent_id','=',0)->limit(3)->get();
        $products = $this->product->where('category_id',$id_cate)->paginate(8);
        $postCategories = $this->postCategories->where('parent_id','=',0)->limit(3)->get();
        $logo = $this->partner->where('features',1)->first();
        return view('frontend.pages.product.category.index',compact('logo','categories','products','postCategories'));
    }
}
