<?php

namespace App\Http\Controllers;

use App\AdminClient;
use App\Traits\DeleteModelTrait;
use App\Traits\StorageImageTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class AdminClientController extends Controller
{
    private $client;
    use StorageImageTrait,DeleteModelTrait;
    public function __construct(AdminClient $client)
    {
        $this->client=$client;
    }
    public function index(){
        $clients = $this->client->latest()->get();
        return view('dashboard.pages.clients.index',compact('clients'));
    }
    public function create(){
        return view('dashboard.pages.clients.add');
    }
    public function store(Request $request){
        try {
            $dataInsert = [
                'name' => $request->name,
                'country' => $request->content,
                'content' => $request->content,
            ];
            $dataImageSlider = $this->storageTraitUpload($request, 'image_path', 'clients');
            if( !empty($dataImageSlider) ) {
                $dataInsert['image_name'] = $dataImageSlider['file_name'];
                $dataInsert['image_path'] = $dataImageSlider['file_path'];
            }
            $result = $this->client->create($dataInsert);
            if($result){
                toast('Thêm mới client thành công','success','top-right');
            }
            else{
                toast('Thêm mới client không thành công','error','top-right');
            }
            return redirect()->route('clients.index');
        } catch (\Exception $exception) {
            Log::error('Lỗi : ' . $exception->getMessage() . '---Line: ' . $exception->getLine());
        }
    }
    public function edit($id){
        $client = $this->client->find($id);
        return view('dashboard.pages.clients.edit',compact('client'));
    }
    public function update(Request $request,$id){
        try {
            $dataUpdate = [
                'name' => $request->name,
                'country' => $request->country,
                'content' => $request->content,
            ];
            $dataImageSlider = $this->storageTraitUpload($request, 'image_path', 'clients');
            if( !empty($dataImageSlider) ) {
                $dataUpdate['image_name'] = $dataImageSlider['file_name'];
                $dataUpdate['image_path'] = $dataImageSlider['file_path'];
            }

            $result = $this->client->find($id)->update($dataUpdate);
            if($result){
                toast('Sửa client thành công','success','top-right');
            }
            else{
                toast('Sửa client không thành công','error','top-right');
            }
            return redirect()->route('clients.index');
        } catch (\Exception $exception) {
            Log::error('Lỗi : ' . $exception->getMessage() . '---Line: ' . $exception->getLine());
        }
    }
    public function delete($id){
        $result = $this->deleteModelTrait($id, $this->client);
        if($result){
                toast('Xóa client thành công','success','top-right');
        }
        else{
            toast('Xóa client không thành công','error','top-right');
        }
        return redirect()->route('clients.index');
    }
}
