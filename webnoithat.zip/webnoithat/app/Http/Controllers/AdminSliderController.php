<?php

namespace App\Http\Controllers;

use App\AdminSlider;
use App\Http\Requests\SliderRequest;
use App\Traits\DeleteModelTrait;
use App\Traits\StorageImageTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use RealRashid\SweetAlert\Facades\Aler;
class AdminSliderController extends Controller
{
   private $slider;
   use StorageImageTrait,DeleteModelTrait;
   public function __construct(AdminSlider $slider)
   {
       $this->slider=$slider;
   }
   public function index(){
       $sliders = $this->slider->latest()->get();
       return view('dashboard.pages.sliders.index',compact('sliders'));
   }
   public function create(){
       return view('dashboard.pages.sliders.add');
   }
   public function store(Request $request){
        try {
            $dataInsert = [
                'title' => $request->title,
                'description' => $request->description,
                'features'   => $request->features
            ];
            $dataImageSlider = $this->storageTraitUpload($request, 'image_path', 'slider');
            if( !empty($dataImageSlider) ) {
                $dataInsert['image_name'] = $dataImageSlider['file_name'];
                $dataInsert['image_path'] = $dataImageSlider['file_path'];
            }
            $result = $this->slider->create($dataInsert);
            if($result){
                toast('Thêm mới slider thành công','success','top-right');
            }
            else{
                toast('Thêm mới slider không thành công','error','top-right');
            }
            return redirect()->route('sliders.index');
        } catch (\Exception $exception) {
            Log::error('Lỗi : ' . $exception->getMessage() . '---Line: ' . $exception->getLine());
        }
    }
    public function edit($id){
        $slider = $this->slider->find($id);
        return view('dashboard.pages.sliders.edit',compact('slider'));
    }
    public function update(Request $request,$id){
        try {
            $dataUpdate = [
                'title' => $request->title,
                'description' => $request->description,
                'features'   => $request->features
            ];
            $dataImageSlider = $this->storageTraitUpload($request, 'image_path', 'slider');
            if( !empty($dataImageSlider) ) {
                $dataUpdate['image_name'] = $dataImageSlider['file_name'];
                $dataUpdate['image_path'] = $dataImageSlider['file_path'];
            }

            $result = $this->slider->find($id)->update($dataUpdate);
            if($result){
                toast('Sửa slider thành công','success','top-right');
            }
            else{
                toast('Sửa slider không thành công','error','top-right');
            }
            return redirect()->route('sliders.index');
        } catch (\Exception $exception) {
            Log::error('Lỗi : ' . $exception->getMessage() . '---Line: ' . $exception->getLine());
        }
    }
    public function delete($id){
        $result = $this->deleteModelTrait($id, $this->slider);
        if($result){
                toast('Xóa slider thành công','success','top-right');
        }
        else{
            toast('Xóa slider không thành công','error','top-right');
        }
        return redirect()->route('sliders.index');
    }
}
