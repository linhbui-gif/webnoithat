<?php

namespace App\Http\Controllers;

use App\AdminClient;
use App\AdminCustomer;
use App\AdminPartner;
use App\AdminPost_categories;
use App\AdminProduct;
use App\AdminProduct_categories;
use App\AdminService;
use App\AdminSlider;
use App\Http\Requests\HomeRequest;
use Illuminate\Http\Request;

class HomePagesController extends Controller
{
    private $service,$category,$client,$partner,$slider,$customer;
    public function __construct(AdminService $service,AdminProduct_categories $category,AdminProduct $product,AdminCustomer $customer,AdminClient $client,AdminPartner $partner,AdminSlider $slider,AdminPost_categories $postCategories)
    {
        $this->service = $service;
        $this->product = $product;
        $this->category = $category;
        $this->client = $client;
        $this->partner = $partner;
        $this->slider = $slider;
        $this->postCategories = $postCategories;
        $this->customer = $customer;
    }
    public function index(){
        $sliders = $this->slider->where('features',null)->get();
        $banner = $this->slider->where('features',1)->first();
        $serviceUps = $this->service->where('type_choose','=',null)->limit(4)->get();
        $serviceDowns = $this->service->where('type_choose','!=',null)->limit(4)->get();
        $categories = $this->category->where('parent_id','=',0)->limit(3)->get();
        $postCategories = $this->postCategories->where('parent_id','=',0)->limit(3)->get();
        $clients = $this->client->get();
        $logo = $this->partner->where('features',1)->first();
        $partners = $this->partner->where('features',null)->get();
        return view('frontend.pages.home.index',compact('logo','sliders','serviceUps','serviceDowns','banner','categories','clients','partners','postCategories'));
    }
    public function store(HomeRequest $request){
        $dataInsert = [
            'phone' => $request->phone,
            'content' => $request->content,
        ];
        $this->customer->create($dataInsert);
        return view('frontend.pages.success.index');
    }
}
