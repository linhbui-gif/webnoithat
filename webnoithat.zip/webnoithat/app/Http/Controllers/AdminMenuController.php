<?php

namespace App\Http\Controllers;
use Illuminate\Support\Str;
use App\AdminMenu;
use App\Components\MenuRecusive;
use App\Http\Requests\MenuRequest;
use App\Traits\DeleteModelTrait;
use Illuminate\Http\Request;
use RealRashid\SweetAlert\Facades\Aler;
class AdminMenuController extends Controller
{
    use DeleteModelTrait;
    private $menuRecusive,$menu;
    public function __construct(MenuRecusive $menuRecusive, AdminMenu $menu)
    {
        $this->menuRecusive=$menuRecusive;
        $this->menu = $menu;
    }
    public function index(){
        $menus = $this->menu->latest()->get();
        return view('dashboard.pages.menus.index',compact('menus'));
    }
    public function create(){
        $optionSelect = $this->menuRecusive->menuRecusiveAdd();
        return view('dashboard.pages.menus.add',compact('optionSelect'));
    }
    public function store(MenuRequest $request){
        $menuCreate = $this->menu->create([
            'name'=> $request->name,
            'parent_id'=>$request->parent_id,
            'slug' => Str::slug($request->name)
        ]);
        if($menuCreate){
            toast('Thêm mới menu thành công','success','top-right');
        }
        else{
            toast('Thêm mới menu không thành công','error','top-right');
        }
        return redirect()->route('menus.index');
    }
    public function edit($id, Request $request)
    {
        $menuFollowIdEdit = $this->menu->find($id);
        $optionSelect = $this->menuRecusive->menuRecusiveEdit($menuFollowIdEdit->parent_id);
        return view('dashboard.pages.menus.edit', compact('optionSelect', 'menuFollowIdEdit'));

    }
    public function update($id, MenuRequest $request)
    {
       $menuUpdate =  $this->menu->find($id)->update([
            'name' => $request->name,
            'parent_id' => $request->parent_id,
            'slug' => str_slug($request->name)
        ]);
        if($menuUpdate){
            toast('Sửa menu thành công','success','top-right');
        }
        else{
            toast('Sửa menu không thành công','error','top-right');
        }
        return redirect()->route('menus.index');
    }
    public function delete($id){
        $menuDelete = $this->DeleteModelTrait($id, $this->menu);
        if($menuDelete){
            toast('Xóa menu thành công','success','top-right');
        }
        else{
            toast('Xóa menu không thành công','error','top-right');
        }
        return redirect()->route('menus.index');
    }
}
