<?php

namespace App\Http\Controllers;

use App\AdminProduct;
use App\AdminProduct_categories;
use App\components\CategoryRecusive;
use App\Product_cate;
use App\Traits\DeleteModelTrait;
use App\Traits\StorageImageTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class AdminProductController extends Controller
{
    private $product,$product_cate,$productCate;
    use StorageImageTrait,DeleteModelTrait;
    public function __construct(AdminProduct $product, AdminProduct_categories $product_cate,Product_cate $productCate)
    {
        $this->product=$product;
        $this->product_cate=$product_cate;
        $this->productCate=$productCate;
    }
    public function getCategory($parent_id){
        $data = $this->product_cate->all();
        $recusive = new CategoryRecusive($data);
        $htmlOpition = $recusive->categoryRecusive($parent_id);
        return $htmlOpition;
    }
    public function index(){
        $products = $this->product->latest()->get();
        return view('dashboard.pages.products.index',compact('products'));
    }
    public function create(){
        $htmlOpition = $this->getCategory($parent_id = '');
        return view('dashboard.pages.products.add',compact('htmlOpition'));
    }
    public function store(Request $request){
        try {
            $dataInsert = [
                'title' => $request->title,
                'content' => $request->content,
                'investor' => $request->investor,
                'code_ct' => $request->code_ct,
                'user_id' => Auth::id(),
                'category_id' => $request->category_id,
                'related_product' => $request->related_product,
                'slug' => str_slug($request->title)
            ];
            $dataImageSlider = $this->storageTraitUpload($request, 'image_path', 'products');
            if( !empty($dataImageSlider) ) {
                $dataInsert['image_name'] = $dataImageSlider['file_name'];
                $dataInsert['image_path'] = $dataImageSlider['file_path'];
            }
            $result = $this->product->create($dataInsert);
            if($result){
                toast('Thêm mới sản phẩm thành công','success','top-right');
            }
            else{
                toast('Thêm mới sản phẩm  không thành công','error','top-right');
            }
            return redirect()->route('products.index');
        } catch (\Exception $exception) {
            Log::error('Lỗi : ' . $exception->getMessage() . '---Line: ' . $exception->getLine());
        }
    }
    public function edit($id){
        $product = $this->product->find($id);
        $htmlOption = $this->getCategory($product->category_id);
        return view('dashboard.pages.products.edit',compact('product','htmlOption'));
    }
    public function update(Request $request,$id){
        try {
            $dataUpdate = [
                'title' => $request->title,
                'content' => $request->content,
                'investor' => $request->investor,
                'code_ct' => $request->code_ct,
                'user_id' => Auth::id(),
                'category_id' => $request->category_id,
                'related_product' => $request->related_product,
                'slug' => str_slug($request->title)
            ];
            $dataImageSlider = $this->storageTraitUpload($request, 'image_path', 'products');
            if( !empty($dataImageSlider) ) {
                $dataUpdate['image_name'] = $dataImageSlider['file_name'];
                $dataUpdate['image_path'] = $dataImageSlider['file_path'];
            }

            $result = $this->product->find($id)->update($dataUpdate);
            if($result){
                toast('Sửa sản phẩm thành công','success','top-right');
            }
            else{
                toast('Sửa sản phẩm không thành công','error','top-right');
            }
            return redirect()->route('products.index');
        } catch (\Exception $exception) {
            Log::error('Lỗi : ' . $exception->getMessage() . '---Line: ' . $exception->getLine());
        }
    }
    public function delete($id){
        $result = $this->deleteModelTrait($id, $this->product);
        if($result){
                toast('Xóa sản phẩm thành công','success','top-right');
        }
        else{
            toast('Xóa sản phẩm không thành công','error','top-right');
        }
        return redirect()->route('products.index');
    }
}
