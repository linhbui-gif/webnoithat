<?php

namespace App\Http\Controllers;

use App\AdminPartner;
use App\AdminPost_categories;
use App\AdminProduct;
use App\AdminProduct_categories;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    private $product;
    public function __construct(AdminPartner $partner,AdminProduct $product,AdminProduct_categories $categories,AdminPost_categories $postCategories)
    {
        $this->product = $product;
        $this->categories = $categories;
        $this->postCategories = $postCategories;
        $this->partner = $partner;
    }
    public function index(){
        $products = $this->product->latest()->paginate(12);
        $logo = $this->partner->where('features',1)->first();
        $categories = $this->categories->where('parent_id','=',0)->limit(3)->get();
        $postCategories = $this->postCategories->where('parent_id','=',0)->limit(3)->get();
        return view('frontend.pages.product.index',compact('logo','products','categories','postCategories'));
    }
    public function detail($id,$slug){
        $product = $this->product->find($id);
        $productRelated = $this->product->where('related_product',1)->get();
        $categories = $this->categories->where('parent_id','=',0)->limit(3)->get();
        $postCategories = $this->postCategories->where('parent_id','=',0)->limit(3)->get();
        $logo = $this->partner->where('features',1)->first();
        return view('frontend.pages.product.detail',compact('logo','product','categories','productRelated','postCategories'));
    }
}
