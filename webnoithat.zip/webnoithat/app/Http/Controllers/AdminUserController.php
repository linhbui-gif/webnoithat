<?php

namespace App\Http\Controllers;

use App\Http\Requests\UserRequest;
use App\Traits\DeleteModelTrait;
use App\Traits\StorageImageTrait;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class AdminUserController extends Controller
{
    private $user;
    use StorageImageTrait,DeleteModelTrait;
    public function __construct(User $user)
    {
        $this->user=$user;
    }
    public function index(){
        $users = $this->user->latest()->get();
        return view('dashboard.pages.users.index',compact('users'));
    }
    public function create(){
        return view('dashboard.pages.users.add');
    }
    public function edit($id){
        $user = $this->user->find($id);
        return view('dashboard.pages.users.edit',compact('user'));
    }
    public function store(UserRequest $request){
        try {
            $dataInsert = [
                'name' => $request->name,
                'email' => $request->email,
                'roles' => $request->roles,
                'password' => bcrypt($request->password)
            ];
            $dataImageSlider = $this->storageTraitUpload($request, 'image_path', 'users');
            if( !empty($dataImageSlider) ) {
                $dataInsert['image_name'] = $dataImageSlider['file_name'];
                $dataInsert['image_path'] = $dataImageSlider['file_path'];
            }
            $result = $this->user->create($dataInsert);
            if($result){
                toast('Thêm mới user thành công','success','top-right');
            }
            else{
                toast('Thêm mới user không thành công','error','top-right');
            }
            return redirect()->route('users.index');
        } catch (\Exception $exception) {
            Log::error('Lỗi : ' . $exception->getMessage() . '---Line: ' . $exception->getLine());
        }
    }

    public function update(Request $request,$id){
        try {
            $dataUpdate = [
                'name' => $request->name,
                'email' => $request->email,
                'roles' => $request->roles,
                'password' => bcrypt($request->password)
            ];
            $dataImageSlider = $this->storageTraitUpload($request, 'image_path', 'users');
            if( !empty($dataImageSlider) ) {
                $dataUpdate['image_name'] = $dataImageSlider['file_name'];
                $dataUpdate['image_path'] = $dataImageSlider['file_path'];
            }

            $result = $this->user->find($id)->update($dataUpdate);
            if($result){
                toast('Sửa user thành công','success','top-right');
            }
            else{
                toast('Sửa user không thành công','error','top-right');
            }
            return redirect()->route('users.index');
        } catch (\Exception $exception) {
            Log::error('Lỗi : ' . $exception->getMessage() . '---Line: ' . $exception->getLine());
        }
    }
    public function delete($id){
        $result = $this->deleteModelTrait($id, $this->user);
        if($result){
                toast('Xóa user thành công','success','top-right');
        }
        else{
            toast('Xóa user không thành công','error','top-right');
        }
        return redirect()->route('users.index');
    }
}
