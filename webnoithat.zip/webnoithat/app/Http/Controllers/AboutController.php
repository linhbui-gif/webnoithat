<?php

namespace App\Http\Controllers;

use App\AdminNew;
use App\AdminPage;
use App\AdminPartner;
use App\AdminPost_categories;
use App\AdminProduct_categories;
use Illuminate\Http\Request;

class AboutController extends Controller
{
    private $pages,$new;
    public function __construct(AdminPartner $partner,AdminPage $pages,AdminNew $new,AdminProduct_categories $categories,AdminPost_categories $postCategories)
    {
        $this->pages = $pages;
        $this->new = $new;
        $this->categories = $categories;
        $this->postCategories = $postCategories;
        $this->partner = $partner;
    }
    public function index(){
        $aboutPages = $this->pages->where('type_pages',null)->first();
        $news = $this->new->latest()->limit(5)->get();
        $logo = $this->partner->where('features',1)->first();
        $categories = $this->categories->where('parent_id','=',0)->limit(3)->get();
        $postCategories = $this->postCategories->where('parent_id','=',0)->limit(3)->get();
        return view('frontend.pages.about.index',compact('logo','aboutPages','news','categories','postCategories'));
    }
}
