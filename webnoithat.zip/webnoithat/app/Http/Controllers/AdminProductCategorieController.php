<?php

namespace App\Http\Controllers;
use Illuminate\Support\Str;
use App\AdminProduct_categories;
use App\components\CategoryRecusive;
use App\Traits\DeleteModelTrait;
use Illuminate\Http\Request;

class AdminProductCategorieController extends Controller
{
    use DeleteModelTrait;
    private $product_cate;
    public function __construct(AdminProduct_categories $product_cate)
    {
        $this->product_cate = $product_cate;
    }
    public function getCategory($parent_id){
        $data = $this->product_cate->all();
        $recusive = new CategoryRecusive($data);
        $htmlOpition = $recusive->categoryRecusive($parent_id);
        return $htmlOpition;
    }
    public function index(){
        $product_categories = $this->product_cate->latest()->get();
        return view('dashboard.pages.product_categories.index',compact('product_categories'));
    }
    public function create(){
       $htmlOpition = $this->getCategory($parent_id = '');
       return view('dashboard.pages.product_categories.add',compact('htmlOpition'));
    }
    public function store(Request $request){
        $product_categoriesCreate = $this->product_cate->create([
            'name'=> $request->name,
            'parent_id'=>$request->parent_id,
            'slug' => Str::slug($request->name)
        ]);
        if($product_categoriesCreate){
            toast('Thêm mới danh mục sản phẩm thành công','success','top-right');
        }
        else{
            toast('Thêm mới danh mục sản phẩm không thành công','error','top-right');
        }
        return redirect()->route('product-categories.index');
    }
    public function edit($id, Request $request)
    {
        $product_cateEdit = $this->product_cate->find($id);
        $htmlOpition = $this->getCategory($product_cateEdit->parent_id);
        return view('dashboard.pages.product_categories.edit', compact('product_cateEdit', 'htmlOpition'));

    }
    public function update($id, Request $request)
    {
       $product_categoriesUpdate =  $this->product_cate->find($id)->update([
            'name' => $request->name,
            'parent_id' => $request->parent_id,
            'slug' => str_slug($request->name)
        ]);
        if($product_categoriesUpdate){
            toast('Sửa danh mục sản phẩm thành công','success','top-right');
        }
        else{
            toast('Sửa danh mục sản phẩm không thành công','error','top-right');
        }
        return redirect()->route('product-categories.index');
    }
    public function delete($id){
        $product_categoriesDelete = $this->DeleteModelTrait($id, $this->product_cate);
        if($product_categoriesDelete){
            toast('Xóa danh mục sản phẩm thành công','success','top-right');
        }
        else{
            toast('Xóa danh mục sản phẩm không thành công','error','top-right');
        }
        return redirect()->route('product-categories.index');
    }
}
