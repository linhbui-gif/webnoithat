<?php

namespace App\Http\Controllers;

use App\AdminCustomer;
use App\Http\Requests\ContactRequest;
use Illuminate\Http\Request;

class CustomersController extends Controller
{
    private $customer;
    public function __construct(AdminCustomer $customer)
    {
        $this->customer = $customer;
    }
    public function store(ContactRequest $request){
        $dataInsert = [
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'content' => $request->content,
        ];

        if(!empty($dataInsert )){
            $this->customer->create($dataInsert);
            return response()->json(['success'=>'ok',]);
        }
        else{
            return response()->json(['error'=>$request->errors()->all()]);
        }
    }
}
