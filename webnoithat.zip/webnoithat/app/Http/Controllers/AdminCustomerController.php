<?php

namespace App\Http\Controllers;

use App\AdminCustomer;
use App\Traits\DeleteModelTrait;
use Illuminate\Http\Request;

class AdminCustomerController extends Controller
{
    private $customers;
    use DeleteModelTrait;
    public function __construct(AdminCustomer $customers)
    {
        $this->customers = $customers;
    }
    public function index(){
        $customers = $this->customers->latest()->paginate();
        return view('dashboard.pages.customers.index',compact('customers'));
    }
    public function detail($id){
        $customer = $this->customers->find($id);
        return view('dashboard.pages.customers.detail',compact('customer'));
    }
    public function delete($id){
        $result = $this->deleteModelTrait($id, $this->customers);
        if($result){
                toast('Xóa khách hàng thành công','success','top-right');
        }
        else{
            toast('Xóa khách hàng không thành công','error','top-right');
        }
        return redirect()->route('customers.index');
    }
}
