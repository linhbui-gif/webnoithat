<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;

class AdminProfileController extends Controller
{
    private $user;
    public function __construct(User $user)
    {
        $this->user=$user;
    }
    public function detail($id){
        $user = $this->user->find($id);
        return view('dashboard.pages.profile.index',compact('user'));
    }
}
