<?php

namespace App\Http\Controllers;

use App\AdminPage;
use App\Traits\DeleteModelTrait;
use App\Traits\StorageImageTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class AdminPageController extends Controller
{
    private $page;
    use StorageImageTrait,DeleteModelTrait;
    public function __construct(AdminPage $page)
    {
        $this->page=$page;
    }
    public function index(){
        $pages = $this->page->latest()->get();
        return view('dashboard.pages.page.index',compact('pages'));
    }
    public function create(){
        return view('dashboard.pages.page.add');
    }
    public function store(Request $request){
        try {
            $dataInsert = [
                'content' => $request->content,
                'type_pages' => $request->type_pages,
            ];
            $dataImageSlider = $this->storageTraitUpload($request, 'image_path', 'pages');
            if( !empty($dataImageSlider) ) {
                $dataInsert['image_name'] = $dataImageSlider['file_name'];
                $dataInsert['image_path'] = $dataImageSlider['file_path'];
            }
            $result = $this->page->create($dataInsert);
            if($result){
                toast('Thêm mới trang thành công','success','top-right');
            }
            else{
                toast('Thêm mới trang không thành công','error','top-right');
            }
            return redirect()->route('pages.index');
        } catch (\Exception $exception) {
            Log::error('Lỗi : ' . $exception->getMessage() . '---Line: ' . $exception->getLine());
        }
    }
    public function edit($id){
        $page = $this->page->find($id);
        return view('dashboard.pages.page.edit',compact('page'));
    }
    public function update(Request $request,$id){
        try {
            $dataUpdate = [
                'content' => $request->content,
                'type_pages' => $request->type_pages,
            ];
            $dataImageSlider = $this->storageTraitUpload($request, 'image_path', 'pages');
            if( !empty($dataImageSlider) ) {
                $dataUpdate['image_name'] = $dataImageSlider['file_name'];
                $dataUpdate['image_path'] = $dataImageSlider['file_path'];
            }
            $result = $this->page->find($id)->update($dataUpdate);
            if($result){
                toast('Sửa trang thành công','success','top-right');
            }
            else{
                toast('Sửa trang không thành công','error','top-right');
            }
            return redirect()->route('pages.index');
        } catch (\Exception $exception) {
            Log::error('Lỗi : ' . $exception->getMessage() . '---Line: ' . $exception->getLine());
        }
    }
    public function delete($id){
        $result = $this->deleteModelTrait($id, $this->page);
        if($result){
                toast('Xóa trang thành công','success','top-right');
        }
        else{
            toast('Xóa trang không thành công','error','top-right');
        }
        return redirect()->route('pages.index');
    }
}
