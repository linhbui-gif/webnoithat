<?php

namespace App\Http\Controllers;

use App\AdminService;
use App\Traits\DeleteModelTrait;
use App\Traits\StorageImageTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class AdminServiceController extends Controller
{
    private $service;
    use StorageImageTrait,DeleteModelTrait;
    public function __construct(AdminService $service)
    {
        $this->service=$service;
    }
    public function index(){
        $services = $this->service->latest()->get();
        return view('dashboard.pages.services.index',compact('services'));
    }
    public function create(){
        return view('dashboard.pages.services.add');
    }
    public function store(Request $request){
        try {
            $dataInsert = [
                'content' => $request->content,
                'type_choose' => $request->type_choose
            ];
            $dataImageSlider = $this->storageTraitUpload($request, 'image_path', 'services');
            if( !empty($dataImageSlider) ) {
                $dataInsert['image_name'] = $dataImageSlider['file_name'];
                $dataInsert['image_path'] = $dataImageSlider['file_path'];
            }
            $result = $this->service->create($dataInsert);
            if($result){
                toast('Thêm mới service thành công','success','top-right');
            }
            else{
                toast('Thêm mới service không thành công','error','top-right');
            }
            return redirect()->route('services.index');
        } catch (\Exception $exception) {
            Log::error('Lỗi : ' . $exception->getMessage() . '---Line: ' . $exception->getLine());
        }
    }
    public function edit($id){
        $service = $this->service->find($id);
        return view('dashboard.pages.services.edit',compact('service'));
    }
    public function update(Request $request,$id){
        try {
            $dataUpdate = [
                'content' => $request->content,
                'type_choose' => $request->type_choose
            ];
            $dataImageSlider = $this->storageTraitUpload($request, 'image_path', 'services');
            if( !empty($dataImageSlider) ) {
                $dataUpdate['image_name'] = $dataImageSlider['file_name'];
                $dataUpdate['image_path'] = $dataImageSlider['file_path'];
            }

            $result = $this->service->find($id)->update($dataUpdate);
            if($result){
                toast('Sửa service thành công','success','top-right');
            }
            else{
                toast('Sửa service không thành công','error','top-right');
            }
            return redirect()->route('services.index');
        } catch (\Exception $exception) {
            Log::error('Lỗi : ' . $exception->getMessage() . '---Line: ' . $exception->getLine());
        }
    }
    public function delete($id){
        $result = $this->deleteModelTrait($id, $this->service);
        if($result){
                toast('Xóa service thành công','success','top-right');
        }
        else{
            toast('Xóa service không thành công','error','top-right');
        }
        return redirect()->route('services.index');
    }
}
