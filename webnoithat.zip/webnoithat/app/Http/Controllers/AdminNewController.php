<?php

namespace App\Http\Controllers;

use App\AdminNew;
use App\AdminPost_categories;
use App\components\CategoryRecusive;
use App\Traits\DeleteModelTrait;
use App\Traits\StorageImageTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
class AdminNewController extends Controller
{
    private $new,$post_cate;
    use StorageImageTrait,DeleteModelTrait;
    public function __construct(AdminNew $new,AdminPost_categories $post_cate)
    {
        $this->new=$new;
        $this->post_cate=$post_cate;
    }
    public function getCategory($parent_id){
        $data = $this->post_cate->all();
        $recusive = new CategoryRecusive($data);
        $htmlOpition = $recusive->categoryRecusive($parent_id);
        return $htmlOpition;
    }
    public function index(){
        $news = $this->new->latest()->get();
        return view('dashboard.pages.news.index',compact('news'));
    }
    public function create(){
        $htmlOpition = $this->getCategory($parent_id = '');
        return view('dashboard.pages.news.add',compact('htmlOpition'));
    }
    public function store(Request $request){
        try {
            $dataInsert = [
                'title' => $request->title,
                'description' => $request->description,
                'content' => $request->content,
                'features' => $request->features,
                'post_id' => $request->post_id,
                'slug' => str_slug($request->title),
                'user_id' => Auth::id(),
            ];
            $dataImageSlider = $this->storageTraitUpload($request, 'image_path', 'news');
            if( !empty($dataImageSlider) ) {
                $dataInsert['image_name'] = $dataImageSlider['file_name'];
                $dataInsert['image_path'] = $dataImageSlider['file_path'];
            }
            $result = $this->new->create($dataInsert);
            if($result){
                toast('Thêm mới bài viết thành công','success','top-right');
            }
            else{
                toast('Thêm mới bài viết không thành công','error','top-right');
            }
            return redirect()->route('news.index');
        } catch (\Exception $exception) {
            Log::error('Lỗi : ' . $exception->getMessage() . '---Line: ' . $exception->getLine());
        }
    }
    public function edit($id){
        $new = $this->new->find($id);
        $htmlOption = $this->getCategory($new->post_id);
        return view('dashboard.pages.news.edit',compact('new','htmlOption'));
    }
    public function update(Request $request,$id){
        try {
            $dataUpdate = [
                'title' => $request->title,
                'description' => $request->description,
                'content' => $request->content,
                'features' => $request->features,
                'post_id' => $request->post_id,
                'slug' => str_slug($request->title),
                'user_id' => Auth::id(),
            ];
            $dataImageSlider = $this->storageTraitUpload($request, 'image_path', 'news');
            if( !empty($dataImageSlider) ) {
                $dataUpdate['image_name'] = $dataImageSlider['file_name'];
                $dataUpdate['image_path'] = $dataImageSlider['file_path'];
            }

            $result = $this->new->find($id)->update($dataUpdate);
            if($result){
                toast('Sửa bài viết thành công','success','top-right');
            }
            else{
                toast('Sửa bài viết không thành công','error','top-right');
            }
            return redirect()->route('news.index');
        } catch (\Exception $exception) {
            Log::error('Lỗi : ' . $exception->getMessage() . '---Line: ' . $exception->getLine());
        }
    }
    public function delete($id){
        $result = $this->deleteModelTrait($id, $this->new);
        if($result){
                toast('Xóa bài viết thành công','success','top-right');
        }
        else{
            toast('Xóa bài viết không thành công','error','top-right');
        }
        return redirect()->route('news.index');
    }
}
