<?php

namespace App\Http\Controllers;

use App\AdminPage;
use App\AdminPartner;
use App\AdminPost_categories;
use App\AdminProduct_categories;
use Illuminate\Http\Request;

class ContactController extends Controller
{
    private $pages;
    public function __construct(AdminPartner $partner,AdminPage $pages,AdminProduct_categories $categories,AdminPost_categories $postCategories)
    {
        $this->pages = $pages;
        $this->categories = $categories;
        $this->postCategories = $postCategories;
        $this->partner = $partner;
    }
    public function index(){
        $contactPages = $this->pages->where('type_pages',1)->first();
        $logo = $this->partner->where('features',1)->first();
        $categories = $this->categories->where('parent_id','=',0)->limit(3)->get();
        $postCategories = $this->postCategories->where('parent_id','=',0)->limit(3)->get();
        return view('frontend.pages.contact.index',compact('logo','contactPages','categories','postCategories'));
    }
}
