<?php

namespace App\Http\Controllers;
use Illuminate\Support\Str;
use App\AdminPost_categories;
use App\components\CategoryRecusive;
use App\Traits\DeleteModelTrait;
use Illuminate\Http\Request;

class AdminPostCategoriesController extends Controller
{
    use DeleteModelTrait;
    private $post_cate;
    public function __construct(AdminPost_categories $post_cate)
    {
        $this->post_cate = $post_cate;
    }
    public function getCategory($parent_id){
        $data = $this->post_cate->all();
        $recusive = new CategoryRecusive($data);
        $htmlOpition = $recusive->categoryRecusive($parent_id);
        return $htmlOpition;
    }
    public function index(){
        $newsCategory = $this->post_cate->latest()->get();
        return view('dashboard.pages.news.category.index',compact('newsCategory'));
    }
    public function create(){
       $htmlOpition = $this->getCategory($parent_id = '');
       return view('dashboard.pages.news.category.add',compact('htmlOpition'));
    }
    public function store(Request $request){
        $post_categoriesCreate = $this->post_cate->create([
            'name'=> $request->name,
            'parent_id'=>$request->parent_id,
            'slug' => Str::slug($request->name)
        ]);
        if($post_categoriesCreate){
            toast('Thêm mới danh mục tin tức thành công','success','top-right');
        }
        else{
            toast('Thêm mới danh mục tin tức không thành công','error','top-right');
        }
        return redirect()->route('newCate.index');
    }
    public function edit($id, Request $request)
    {
        $post_cateEdit = $this->post_cate->find($id);
        $htmlOpition = $this->getCategory($post_cateEdit->parent_id);
        return view('dashboard.pages.news.category.edit', compact('post_cateEdit', 'htmlOpition'));

    }
    public function update($id, Request $request)
    {
       $post_categoriesUpdate =  $this->post_cate->find($id)->update([
            'name' => $request->name,
            'parent_id' => $request->parent_id,
            'slug' => str_slug($request->name)
        ]);
        if($post_categoriesUpdate){
            toast('Sửa danh mục tin tức thành công','success','top-right');
        }
        else{
            toast('Sửa danh mục tin tức không thành công','error','top-right');
        }
        return redirect()->route('newCate.index');
    }
    public function delete($id){
        $post_categoriesDelete = $this->DeleteModelTrait($id, $this->post_cate);
        if($post_categoriesDelete){
            toast('Xóa danh mục tin tức thành công','success','top-right');
        }
        else{
            toast('Xóa danh mục tin tức không thành công','error','top-right');
        }
        return redirect()->route('newCate.index');
    }
}
