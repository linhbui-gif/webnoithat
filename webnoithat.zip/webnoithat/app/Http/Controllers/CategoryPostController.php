<?php

namespace App\Http\Controllers;

use App\AdminNew;
use App\AdminPartner;
use App\AdminPost_categories;
use App\AdminProduct_categories;
use Illuminate\Http\Request;

class CategoryPostController extends Controller
{
    private $category;
    public function __construct(AdminPartner $partner,AdminPost_categories $postCategories,AdminNew $new,AdminProduct_categories $category)
    {
        $this->postCategories = $postCategories;
        $this->new = $new;
        $this->category = $category;
        $this->partner = $partner;
    }
    public function index($slug,$id_cate){
        $postCategories = $this->postCategories->where('parent_id','=',0)->limit(3)->get();
        $categories = $this->category->where('parent_id','=',0)->limit(3)->get();
        $news = $this->new->where('post_id',$id_cate)->paginate(8);
        $logo = $this->partner->where('features',1)->first();
        return view('frontend.pages.new.category.index',compact('logo','categories','news','postCategories'));
    }
}
