<?php

namespace App\Http\Controllers;

use App\AdminPartner;
use App\Traits\DeleteModelTrait;
use App\Traits\StorageImageTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class AdminPartnerController extends Controller
{
    private $partner;
    use StorageImageTrait,DeleteModelTrait;
    public function __construct(AdminPartner $partner)
    {
        $this->partner = $partner;
    }
    public function index(){
        $partners = $this->partner->latest()->get();
        return view('dashboard.pages.partners.index',compact('partners'));
    }
    public function create(){
        return view('dashboard.pages.partners.add');
    }
    public function store(Request $request){
        try {
            $dataInsert = [
                'features'   => $request->features
            ];
            $dataImageSlider = $this->storageTraitUpload($request, 'image_path', 'partners');
            if( !empty($dataImageSlider) ) {
                $dataInsert['image_name'] = $dataImageSlider['file_name'];
                $dataInsert['image_path'] = $dataImageSlider['file_path'];
            }
            $result = $this->partner->create($dataInsert);
            if($result){
                toast('Thêm mới partner thành công','success','top-right');
            }
            else{
                toast('Thêm mới partner không thành công','error','top-right');
            }
            return redirect()->route('partners.index');
        } catch (\Exception $exception) {
            Log::error('Lỗi : ' . $exception->getMessage() . '---Line: ' . $exception->getLine());
        }
    }
    public function edit($id){
        $partner = $this->partner->find($id);
        return view('dashboard.pages.partners.edit',compact('partner'));
    }
    public function update(Request $request,$id){
        try {
            $dataUpdate = [
                'features'   => $request->features
            ];
            $dataImageSlider = $this->storageTraitUpload($request, 'image_path', 'partners');
            if( !empty($dataImageSlider) ) {
                $dataUpdate['image_name'] = $dataImageSlider['file_name'];
                $dataUpdate['image_path'] = $dataImageSlider['file_path'];
            }

            $result = $this->partner->find($id)->update($dataUpdate);
            if($result){
                toast('Sửa partner thành công','success','top-right');
            }
            else{
                toast('Sửa partner không thành công','error','top-right');
            }
            return redirect()->route('partners.index');
        } catch (\Exception $exception) {
            Log::error('Lỗi : ' . $exception->getMessage() . '---Line: ' . $exception->getLine());
        }
    }
    public function delete($id){
        $result = $this->deleteModelTrait($id, $this->partner);
        if($result){
                toast('Xóa partner thành công','success','top-right');
        }
        else{
            toast('Xóa partner không thành công','error','top-right');
        }
        return redirect()->route('partners.index');
    }
}
