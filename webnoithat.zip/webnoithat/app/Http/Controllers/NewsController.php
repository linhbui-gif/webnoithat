<?php

namespace App\Http\Controllers;

use App\AdminNew;
use App\AdminPartner;
use App\AdminPost_categories;
use App\AdminProduct_categories;
use Illuminate\Http\Request;

class NewsController extends Controller
{
    private $new;
    public function __construct(AdminPartner $partner,AdminNew $new,AdminProduct_categories $categories,AdminPost_categories $postCategories)
    {
        $this->new = $new;
        $this->categories = $categories;
        $this->postCategories = $postCategories;
        $this->partner = $partner;
    }
    public function index(){
        $news = $this->new->latest()->paginate(12);
        $logo = $this->partner->where('features',1)->first();
        $categories = $this->categories->where('parent_id','=',0)->limit(3)->get();
        $postCategories = $this->postCategories->where('parent_id','=',0)->limit(3)->get();
        return view('frontend.pages.new.index',compact('logo','news','categories','postCategories'));
    }
    public function detail($id){
        $new = $this->new->find($id);
        $logo = $this->partner->where('features',1)->first();
        $newFeatures = $this->new->where('features',0)->limit(6)->get();
        $news = $this->new->latest()->limit(5)->get();
        $categories = $this->categories->where('parent_id','=',0)->limit(3)->get();
        $postCategories = $this->postCategories->where('parent_id','=',0)->limit(3)->get();
        return view('frontend.pages.new.detail',compact('logo','new','newFeatures','news','categories','postCategories'));
    }
}
