<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AdminProduct_categories extends Model
{
    use SoftDeletes;
    protected $guarded = [];
    protected $table = 'admin_product_categories';
    public function categoryChildrent(){
        return $this->hasMany(AdminProduct_categories::class,'parent_id');
    }
    public function parent()
    {
        return $this->belongsTo(self::class, 'parent_id');
    }
    public function products()
    {
        return $this->hasMany(AdminProduct::class,'category_id');
    }
}
