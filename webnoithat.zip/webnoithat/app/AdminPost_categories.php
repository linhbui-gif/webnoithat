<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AdminPost_categories extends Model
{
    use SoftDeletes;
    protected $guarded = [];
    protected $table = 'admin_post_categories';
    public function categoryChildrent(){
        return $this->hasMany(AdminPost_categories::class,'parent_id');
    }
    public function parent()
    {
        return $this->belongsTo(self::class, 'parent_id');
    }
    public function news()
    {
        return $this->hasMany(AdminNew::class,'post_id');
    }
}
