
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('dashboard.layouts.content-header', ['name' => '', 'key' => 'Sửa'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form action="<?php echo e(route('partners.update',['id'=> $partner ?? ''->id])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label>Hình ảnh</label>
            <input type="file"
                   class="form-control-file"
                   name="image_path"
            >
            <div class="col-md-4 feature_image_container">
                <div class="row">
                    <img class="feature_image" width="200" src="<?php echo e($partner ?? ''->image_path); ?>" alt="">
                </div>
            </div>
        </div>
        <div class="form-check mb-3">
            <input class="form-check-input" type="checkbox" id="inlineCheckbox1" name="features" value="1"
            <?php if($partner ->features == 1): ?>
                <?php echo e("checked"); ?>

            <?php endif; ?>
            >
            <label class="form-check-label" for="inlineCheckbox1">Hiển thị là logo</label>
        </div>
        <button type="submit" class="btn btn-primary">Sửa đối tác</button>
        <button type="button" class="btn btn-info"><a href="<?php echo e(route('partners.index')); ?>" style="color: white;text-decoration: none;"> Trở về</a></button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\webnoithat\resources\views/dashboard/pages/partners/edit.blade.php ENDPATH**/ ?>