
<?php $__env->startSection('content'); ?>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <?php echo $__env->make('dashboard.layouts.content-header', ['name' => 'khách hàng', 'key' => 'Thông tin'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <ul class="list-group list-group-flush">
        <li class="list-group-item">Họ và Tên : <?php echo e($customer->name); ?></li>
        <li class="list-group-item">Email : <?php echo e($customer->email); ?></li>
        <li class="list-group-item">Số điện thoại : <?php echo e($customer->phone); ?></li>
        <li class="list-group-item">Nội dung : <?php echo e($customer->content); ?></li>
      </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\webnoithat\resources\views/dashboard/pages/customers/detail.blade.php ENDPATH**/ ?>