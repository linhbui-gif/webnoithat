
<?php $__env->startSection('content'); ?>

    <div class="products__body">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="products__intro">
                        <p class="produScts__intro-content"><?php echo e(getConfig('text-san-pham')); ?></p>
                      </div>
                </div>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($productItem): ?>
                        <div class="col-md-6 col-lg-3">
                            <div class="products__item">
                                <div class="products__item-img"><a class="products__item-link" href="<?php echo e(route('product.detail',['id'=>$productItem->id,'slug'=>$productItem->slug])); ?>" title="title"><img
                                      class="lazyload"   data-original="<?php echo e($productItem->image_path); ?>"
                                            alt="thiết-kế-nhà-ống-diện-tích-100m2"></a></div>
                                <div class="products__item-info">
                                    <h4 class="products__item-title"><a href="<?php echo e(route('product.detail',['id'=>$productItem->id,'slug'=>$productItem->slug])); ?>" title="title"><?php echo e($productItem->title); ?></a>
                                    </h4>
                                    <ul class="products__item-content">
                                        <li><i class="fas fa-barcode"></i>Mã số CT: <?php echo e($productItem->code_ct); ?></li>
                                        <li><i class="fas fa-male"></i>Chủ đầu tư:<?php echo e($productItem->investor); ?></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                      <?php echo e('asdasd'); ?>

                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <div class="products__pagination">
                <?php echo e($products->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\webnoithat\resources\views/frontend/pages/product/category/index.blade.php ENDPATH**/ ?>