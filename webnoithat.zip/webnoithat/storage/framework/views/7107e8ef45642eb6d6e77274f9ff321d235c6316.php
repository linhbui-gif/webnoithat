
<?php $__env->startSection('content'); ?>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <?php echo $__env->make('dashboard.layouts.content-header', ['name' => 'danh mục tin tức', 'key' => 'Danh sách'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <a href="<?php echo e(route('newCate.create')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-plus fa-sm text-white-50"></i> Thêm danh mục tin tức</a>
    </div>
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Tên danh mục</th>
                            <th>Slug</th>
                            <th>Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $newsCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newcateItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($newcateItem->id); ?></td>
                                <td><?php echo e($newcateItem->name); ?></td>
                                <td><?php echo e($newcateItem->slug); ?></td>
                                <td>
                                    <a href="<?php echo e(route('newCate.edit', ['id' => $newcateItem->id])); ?>"
                                        class="btn btn-danger btn-circle">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="<?php echo e(route('newCate.delete', ['id' => $newcateItem->id])); ?>"
                                        class="btn btn-danger btn-circle">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\webnoithat\resources\views/dashboard/pages/news/category/index.blade.php ENDPATH**/ ?>