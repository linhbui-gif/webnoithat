
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('dashboard.layouts.content-header', ['name' => ' bài viết', 'key' => 'Sửa'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form action="<?php echo e(route('news.update',['id'=> $new->id])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label>Tên</label>
        <input class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="title" placeholder="Nhập tên..." value="<?php echo e($new->title); ?>" >
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger  mt-2"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label>Mô tả</label>
            <input class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" placeholder="Nhập mô tả..." value="<?php echo e($new->description); ?>">
            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger  mt-2"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="exampleFormControlSelect1">Nhập danh mục cho bài viết</label>
            <select class="form-control" id="exampleFormControlSelect1" name="post_id">
                <option value="">Chọn danh mục</option>
                <?php echo $htmlOption; ?>

            </select>
          </div>
        <div class="form-group">
            <label>Nội dung</label>
            <textarea class="form-control tinymce_editor_init"  rows="10" name="content"><?php echo $new->content; ?></textarea>
        </div>
        <div class="form-group">
            <label>Ảnh bài viết</label>
            <input type="file"
                   class="form-control-file"
                   name="image_path"
            >
            <div class="col-md-4 feature_image_container">
                <div class="row">
                    <img class="feature_image" width="200" src="<?php echo e($new->image_path); ?>" alt="">
                </div>
            </div>
        </div>
        <div class="form-check mb-3">
            <input class="form-check-input" type="checkbox" value="0" name="features" id="defaultCheck1"
            <?php if($new->features === 0): ?>
                <?php echo e("checked"); ?>

            <?php endif; ?>
            >
            <label class="form-check-label" for="defaultCheck1">
              Hiển thị là bài viết nổi bật
            </label>
          </div>
        <button type="submit" class="btn btn-primary">Sửa bài viết</button>
        <button type="button" class="btn btn-info"><a href="<?php echo e(route('news.index')); ?>" style="color: white;text-decoration: none;"> Trở về</a></button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\webnoithat\resources\views/dashboard/pages/news/edit.blade.php ENDPATH**/ ?>