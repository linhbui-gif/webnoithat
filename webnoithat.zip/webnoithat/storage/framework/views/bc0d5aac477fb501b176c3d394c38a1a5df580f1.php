
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('dashboard.layouts.content-header', ['name' => 'cài đặt', 'key' => 'Thêm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form action="<?php echo e(route('settings.store') . '?type=' . request()->type); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label>Cấu hình tên</label>
            <input type="text"
                   class="form-control"
                   name="config_key"
                   placeholder="Nhập tên cài đặt..."
            >
        </div>
        <?php if(request()->type === 'Text'): ?>
            <div class="form-group">
                <label>Cấu hình giá trị</label>
                <input type="text"
                       class="form-control"
                       name="config_value"
                       placeholder="Nhập giá trị..."
                >
            </div>
            <?php elseif(request()->type === 'Textarea'): ?>
            <div class="form-group">
                <label>Cấu hình giá trị</label>
                <textarea
                       class="form-control"
                       name="config_value"
                       placeholder="Nhập config value"
                       rows="5"
                ></textarea>
            </div>

        <?php endif; ?>
        <button type="submit" class="btn btn-primary">Thêm cài đặt</button>
        <button type="button" class="btn btn-info"><a href="<?php echo e(route('settings.index')); ?>" style="color: white;text-decoration: none;"> Trở về</a></button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\webnoithat\resources\views/dashboard/pages/settings/add.blade.php ENDPATH**/ ?>