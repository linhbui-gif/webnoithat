<?php if($postCategoryItemParent->categoryChildrent->count()): ?>
        <ul class="sub-menu">
            <?php $__currentLoopData = $postCategoryItemParent->categoryChildrent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryChild): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="sub-menu__item">
                    <a class="sub-menu__link" href="<?php echo e(route('category-new.new',['slug'=>$categoryChild->slug,'id'=>$categoryChild->id])); ?>"><?php echo e($categoryChild->name); ?></a>
                    <?php if($categoryChild->categoryChildrent->count()): ?>
                       <?php echo $__env->make('frontend.components.menu.childMenuPost',['postCategoryItemParent'=>$categoryChild], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
<?php endif; ?><?php /**PATH D:\xampp\htdocs\webnoithat\resources\views/frontend/components/menu/childMenuPost.blade.php ENDPATH**/ ?>