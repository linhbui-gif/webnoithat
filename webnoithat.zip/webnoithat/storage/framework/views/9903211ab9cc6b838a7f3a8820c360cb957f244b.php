
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('dashboard.layouts.content-header', ['name' => 'danh mục tin tức', 'key' => 'Thêm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form action="<?php echo e(route('newCate.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label>Tên danh mục</label>
            <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" placeholder="Nhập tên danh mục tin tức" value="<?php echo e(old('name')); ?>">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label >Danh mục cha</label>
            <select class="form-control" name="parent_id">
              <option value="0">Chọn danh mục cha</option>
              <?php echo $htmlOpition; ?>

            </select>
          </div>

        <button type="submit" class="btn btn-primary">Thêm danh mục tin tức</button>
        <button type="button" class="btn btn-info"><a href="<?php echo e(route('newCate.index')); ?>" style="color: white;text-decoration: none;"> Trở về</a></button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\webnoithat\resources\views/dashboard/pages/news/category/add.blade.php ENDPATH**/ ?>