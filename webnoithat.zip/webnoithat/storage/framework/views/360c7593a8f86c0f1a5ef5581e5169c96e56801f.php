
<?php $__env->startSection('content'); ?>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <?php echo $__env->make('dashboard.layouts.content-header', ['name' => 'người dùng', 'key' => 'Danh sách'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <a href="<?php echo e(route('users.create')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-plus fa-sm text-white-50"></i> Thêm người dùng</a>
    </div>
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Tên</th>
                            <th>Email</th>
                            <th>Hình ảnh</th>
                            <th>Quyền</th>
                            <th>Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($userItem->id); ?></td>
                                <td><?php echo e($userItem->name); ?></td>
                                <td><?php echo e($userItem->email); ?></td>
                                <td>
                                   <img src="<?php echo e($userItem->image_path); ?>" width="200" alt="">
                                </td>
                                <td><?php echo e($userItem->roles === 0 ? "admin" : "user"); ?></td>
                                <td>
                                    <a href="<?php echo e(route('users.edit', ['id' => $userItem->id])); ?>"
                                        class="btn btn-danger btn-circle">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="<?php echo e(route('users.delete', ['id' => $userItem->id])); ?>"
                                        class="btn btn-danger btn-circle">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\webnoithat\resources\views/dashboard/pages/users/index.blade.php ENDPATH**/ ?>