<div class="partner">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <h2 class="partner__title title">AN CƯỜNG HÂN HẠNH ĐỒNG HÀNH CÙNG ĐỐI TÁC</h2>
          <div class="partner__box owl-carousel owl-theme">
            <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partnerItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="partner__item"><img class="lazyload" data-original="<?php echo e($partnerItem->image_path); ?>" alt="đối tác"></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </div>
    </div>
  </div><?php /**PATH D:\xampp\htdocs\webnoithat\resources\views/frontend/components/home/partner.blade.php ENDPATH**/ ?>