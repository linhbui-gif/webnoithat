
<?php $__env->startSection('content'); ?>
    <div class="about">
        <div class="container">
            <div class="row">
                <div class="col-12 col-sm-9">
                    <div class="about__content">
                        <?php echo $aboutPages->content; ?>

                    </div>
                </div>
                <!-- Start Sidebar-->
                <?php echo $__env->make('frontend.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- End Sidebar-->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\webnoithat\resources\views/frontend/pages/about/index.blade.php ENDPATH**/ ?>