<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <!-- Favicon-->
    <link rel="shortcut icon" type="image/x-icon" href="images/layout/logo.png">
    <!-- Bootstrap-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900&amp;display=swap"
        rel="stylesheet">
    <!-- Owl Carousel CSS-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">
    <!-- Main CSS-->
    <link href="<?php echo e(asset('interface/css/main.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body class="ts-back-to-top-mobile">
    <div class="wrapper" id="wrap">
        <!-- Start Header-->
        <?php echo $__env->make('frontend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End Header-->
        <?php echo $__env->yieldContent('content'); ?>
        <!-- Start Footer-->
        <?php echo $__env->make('frontend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <a href="tel:<?php echo e(getConfig('phone')); ?>">
            <div class="hotline">
                <span class="before-hotline">Hotline:</span>
                <span class="hotline-number"><?php echo e(getConfig('phone')); ?></span>
            </div>
        </a>
        <?php echo $__env->make('frontend.layouts.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <!-- Jquery-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- Owl Carousel-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <!-- jquery.elevateZoom-3.0.8.min.js-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/elevatezoom/3.0.8/jquery.elevatezoom.js"
        integrity="sha512-ZewoOcnKwYlbLtvwOHyviu/wr3HeGa53p2HEwZBdCscAsQVnwbZZzLfaE2aDVmAJ7lzjujxKL2SgdP8uj69q7Q=="
        crossorigin="anonymous"></script>
    <!-- Lazyload-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.lazyload/1.9.1/jquery.lazyload.min.js"></script>
    <!-- Main Js-->
    <script src="<?php echo e(asset('interface/js/main.js')); ?>"></script>
    <script>
        if (!sessionStorage.adModal) {
            setTimeout(function() {
                $('#admodal').find('.item').first().addClass('active');
                $('#admodal').modal({
                    backdrop: 'static',
                    keyboard: false
                });
            }, 20000);
        }

    </script>
    <!--Start of Tawk.to Script-->
    <script type="text/javascript">
        var Tawk_API = Tawk_API || {},
            Tawk_LoadStart = new Date();
        (function() {
            var s1 = document.createElement("script"),
                s0 = document.getElementsByTagName("script")[0];
            s1.async = true;
            s1.src = 'https://embed.tawk.to/5f584af74704467e89ed52cd/default';
            s1.charset = 'UTF-8';
            s1.setAttribute('crossorigin', '*');
            s0.parentNode.insertBefore(s1, s0);
        })();

    </script>
    <!--End of Tawk.to Script-->
    <?php echo $__env->yieldContent('js'); ?>
</body>

</html>
<?php /**PATH D:\xampp\htdocs\webnoithat\resources\views/frontend/master.blade.php ENDPATH**/ ?>