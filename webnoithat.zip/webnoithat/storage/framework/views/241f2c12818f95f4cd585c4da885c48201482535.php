<div class="products section">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="products__section-box">
            <h2 class="products__section-title title"><a class="products__section-link" href="#" title="title"><?php echo e($categoryItem->name); ?></a></h2>
              <div class="products__box owl-carousel owl-theme">
                <?php $__currentLoopData = $categoryItem->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productCate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="products__item">
                    <div class="products__item-img"><a class="products__item-link" href="<?php echo e(route('product.detail',['id'=>$productCate->id,'slug'=>$productCate->slug])); ?>" title="title"><img
                          class="lazyload" data-original="<?php echo e($productCate->image_path); ?>"
                          alt="mau-biet-thu-1-tang-4-phong-ngu-sieu-dep"></a></div>
                    <div class="products__item-info">
                    <h4 class="products__item-title"><a href="<?php echo e(route('product.detail',['id'=>$productCate->id,'slug'=>$productCate->slug])); ?>" title="title"><?php echo e($productCate->title); ?></a></h4>
                      <ul class="products__item-content">
                        <li><i class="fas fa-barcode"></i>Mã số CT: <?php echo e($productCate->code_ct); ?> </li>
                        <li><i class="fas fa-male"></i>Chủ đầu tư: <?php echo e($productCate->investor); ?> </li>
                      </ul>
                    </div>
                  </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>

          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
      </div>
    </div>
  </div><?php /**PATH D:\xampp\htdocs\webnoithat\resources\views/frontend/components/home/product.blade.php ENDPATH**/ ?>