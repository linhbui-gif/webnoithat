<div class="customer">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <h2 class="customer__title title">khách hàng nói về an cường</h2>
          <p class="customer__content text-center mb-3">Những công trình do Kiến Trúc An Cường tạo ra mang lại sự hài
            lòng của khách hàng và đó là món quà quý đối với chúng tôi. Những lời nhận xét của khách hàng là động lực
            để chúng tôi nâng cao chất lượng đội ngũ và làm hài lòng khách hàng hơn nữa!</p>
          <div class="customer__box owl-carousel owl-theme">
            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clientItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="customer__item">
                <div class="customer__item-img"><img class="lazyload" data-original="<?php echo e($clientItem->image_path); ?>"
                    alt="Mau-biet-thu-vuon-1-tang-dep"></div>
                <div class="customer__item-info">
                  <p class="customer__item-content"><?php echo e($clientItem->content); ?></p>
                  <i class="fas fa-quote-right"></i>
                  <p class="customer__item-name text-center"><b><?php echo e($clientItem->name); ?></b></p>
                  <p class="customer__item-address text-center"><?php echo e($clientItem->country); ?></p>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </div>
    </div>
  </div><?php /**PATH D:\xampp\htdocs\webnoithat\resources\views/frontend/components/home/customer.blade.php ENDPATH**/ ?>