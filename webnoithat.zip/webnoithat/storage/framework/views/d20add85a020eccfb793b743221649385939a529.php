
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('dashboard.layouts.content-header', ['name' => 'service', 'key' => 'Thêm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form action="<?php echo e(route('services.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label>Nội dung</label>
            <textarea class="form-control <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="content" placeholder="Nhập nội dung..."></textarea>
            <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger  mt-2"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label>Ảnh service</label>
            <input type="file"
                   class="form-control-file"
                   name="image_path"
            >
        </div>
        <div class="form-check mb-3">
            <input class="form-check-input" type="checkbox" id="inlineCheckbox1" name="type_choose" value="1">
            <label class="form-check-label" for="inlineCheckbox1">Hiển thị cho phần tại sao bạn chọn chúng tôi</label>
        </div>
        <button type="submit" class="btn btn-primary">Thêm service</button>
        <button type="button" class="btn btn-info"><a href="<?php echo e(route('services.index')); ?>" style="color: white;text-decoration: none;"> Trở về</a></button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\webnoithat\resources\views/dashboard/pages/services/add.blade.php ENDPATH**/ ?>