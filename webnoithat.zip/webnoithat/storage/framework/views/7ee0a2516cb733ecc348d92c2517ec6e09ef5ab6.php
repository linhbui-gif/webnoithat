
<div class="header">
    <div class="header__info">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="header__info-box">
              <p class="header__info-email"><span><i class="fa fa-envelope"></i><a style="color: white;" href="mailto:<?php echo e(getConfig('email')); ?>"><?php echo e(getConfig('email')); ?></a></span>
              </p>
              <p class="header__info-phone"><span> <i class="fa fa-phone"></i><a href="tel:<?php echo e(getConfig('phone')); ?>"><?php echo e(getConfig('phone')); ?></a></span></p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="header__menu">
      <div class="container">
        <?php echo $__env->make('frontend.components.menu.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>
  </div><?php /**PATH D:\xampp\htdocs\webnoithat\resources\views/frontend/layouts/header.blade.php ENDPATH**/ ?>