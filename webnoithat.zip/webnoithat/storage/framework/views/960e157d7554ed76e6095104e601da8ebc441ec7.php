<div class="banner" style="background: url('<?php echo e($banner->image_path); ?>')">
    <div class="container">
      <div class="banner__title d-flex  flex-wrap" id="banner__title">
        <h3><?php echo e($banner->title); ?></h3>
        <button class="btn btn-primary">
        <a href="<?php echo e(getConfig('link-banner')); ?>" class="btn__button" style="color: white;">Xem thêm</a>
        </button>
      </div>
    </div>
  </div><?php /**PATH D:\xampp\htdocs\webnoithat\resources\views/frontend/components/home/banner.blade.php ENDPATH**/ ?>