
<?php $__env->startSection('content'); ?>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <?php echo $__env->make('dashboard.layouts.content-header', ['name' => 'setting', 'key' => 'Danh sách'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="btn-group float-right">
            <a class="btn dropdown-toggle" data-toggle="dropdown" href="#">
                Thêm cài đặt
                <span class="caret"></span>
            </a>
            <ul class="dropdown-menu pl-3">
                <li class="mb-2"><a href="<?php echo e(route('settings.create') . '?type=Text'); ?>">Text</a></li>
                <li><a href="<?php echo e(route('settings.create') . '?type=Textarea'); ?>">Textarea</a></li>
            </ul>
        </div>
    </div>
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th scope="col">#id</th>
                        <th scope="col">Tên cấu hình</th>
                        <th scope="col">Gía trị</th>
                        <th scope="col">Hành động</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($setting->id); ?></th>
                            <td><?php echo e($setting->config_key); ?></td>
                            <td><?php echo e($setting->config_value); ?></td>
                            <td>
                                <a href="<?php echo e(route('settings.edit', ['id' => $setting->id]) . '?type=' . $setting->type); ?>"
                                    class="btn btn-danger btn-circle"> <i class="fas fa-edit"></i></a>
                                <a href="<?php echo e(route('settings.delete', ['id' => $setting->id])); ?>"
                                   class="btn btn-danger btn-circle"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\webnoithat\resources\views/dashboard/pages/settings/index.blade.php ENDPATH**/ ?>