
<?php $__env->startSection('content'); ?>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <?php echo $__env->make('dashboard.layouts.content-header', ['name' => ' đánh giá khách hàng', 'key' => 'Danh sách'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <a href="<?php echo e(route('news.create')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-plus fa-sm text-white-50"></i> Thêm bài viết</a>
    </div>
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Tên</th>
                            <th>Mô tả</th>
                            <th >Nội dung </th>
                            <th >Tin tức nổi bật </th>
                            <th>Hình ảnh</th>
                            <th>Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($newItem->id); ?></td>
                                <td><?php echo e($newItem->title); ?></td>
                                <td style="width: 300px"><?php echo e($newItem->description); ?></td>
                                <td style="width: 300px"><?php echo e($newItem->content); ?></td>
                                <td><?php echo e($newItem->features === 0 ? "Tin tức nổi bật" : ""); ?></td>
                                <td>
                                   <img src="<?php echo e($newItem->image_path); ?>" width="200" alt="">
                                </td>
                                <td>
                                    <a href="<?php echo e(route('news.edit', ['id' => $newItem->id])); ?>"
                                        class="btn btn-danger btn-circle">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="<?php echo e(route('news.delete', ['id' => $newItem->id])); ?>"
                                        class="btn btn-danger btn-circle">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\webnoithat\resources\views/dashboard/pages/news/index.blade.php ENDPATH**/ ?>