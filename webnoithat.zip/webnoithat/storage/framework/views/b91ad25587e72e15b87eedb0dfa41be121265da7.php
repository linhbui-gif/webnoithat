
<?php $__env->startSection('content'); ?>
    <!-- Start slider-->
    <?php echo $__env->make('frontend.components.home.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End sliders-->
    <!-- Start service-->
    <?php echo $__env->make('frontend.components.home.service', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End service-->
    <!-- Start banner-->
    <?php echo $__env->make('frontend.components.home.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End banner-->
    <!-- Start product-->
    <?php echo $__env->make('frontend.components.home.product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End product-->
    <!-- Start Customer-->
    <?php echo $__env->make('frontend.components.home.customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Customer-->
    <!-- Start partner-->
    <?php echo $__env->make('frontend.components.home.partner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End partner-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\webnoithat\resources\views/frontend/pages/home/index.blade.php ENDPATH**/ ?>