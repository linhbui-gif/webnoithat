<div class="modal fade" id="admodal" role="dialog" tabindex="-1">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Vui lòng để lại lời nhắn. Chuyên viên tư vấn của Big I Home sẽ liên hệ và tư vấn bạn ngay</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        </div>
        <div class="modal-body">
          <form method="POST" action="<?php echo e(route('form.store')); ?>">
            <?php echo csrf_field(); ?>
              <div class="form-modal-interval" >
                <div class="form-group">
                    <label class="col-form-label" for="recipient-tel">Số điện thoại của bạn</label>
                    <input class="form-control" name="phone" id="recipient-tel" type="text">
                  </div>
                  <div class="form-group">
                    <label class="col-form-label" for="message-text">Để lại lời nhắn cho chúng tôi</label>
                    <textarea class="form-control" name="content" id="message-text"></textarea>
                  </div>
                  <button class="btn btn-secondary" type="button" data-dismiss="modal">Đóng</button>
                  <button class="btn btn-primary" id="submit-interval" type="submit">Gửi ngay</button>
                  <?php echo $__env->make('frontend.layouts.spinner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php /**PATH D:\xampp\htdocs\webnoithat\resources\views/frontend/components/home/modal.blade.php ENDPATH**/ ?>