
<?php $__env->startSection('content'); ?>
    <div class="posts">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="products__intro">
                        <p class="produScts__intro-content"><?php echo e(getConfig('text-gioi-thieu')); ?></p>
                      </div>
                </div>
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-lg-3 mb-2">
                            <a class="card posts__item" href="<?php echo e(route('new.detail',['id'=>$newItem->id,'slug'=>$newItem->slug])); ?>"><img
                                    class="card-img-top posts__item-img lazyload" data-original="<?php echo e($newItem->image_path); ?>"
                                    alt="thiet-ke-noi-that-chung-cu">
                                <div class="card-body posts__item-info text-center">
                                    <h5 class="card-title posts__item-title"> <?php echo e($newItem->title); ?></h5>
                                    <div class="divider"></div>
                                    <p class="card-text"><?php echo e($newItem->description); ?>

                                    </p>
                                </div>
                                
                            </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="posts__pagination"><?php echo e($news->links()); ?></div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\webnoithat\resources\views/frontend/pages/new/category/index.blade.php ENDPATH**/ ?>