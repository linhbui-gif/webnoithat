
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('dashboard.layouts.content-header', ['name' => ' sản phẩm', 'key' => 'Sửa'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form action="<?php echo e(route('products.update',['id'=>$product->id])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label>Tên sản phẩm</label>
            <input class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="title" value="<?php echo e($product->title); ?>" placeholder="Nhập tên..." >
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger  mt-2"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label>Chủ đầu tư</label>
            <input class="form-control <?php $__errorArgs = ['investor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="investor" placeholder="Nhập chủ đầu tư..." value="<?php echo e($product->investor); ?>">
            <?php $__errorArgs = ['investor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger  mt-2"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label>Mã code CT</label>
        <input class="form-control <?php $__errorArgs = ['code_ct'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="code_ct" placeholder="Nhập mã CT..." value="<?php echo e($product->code_ct); ?>">
            <?php $__errorArgs = ['code_ct'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger  mt-2"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="exampleFormControlSelect1">Nhập danh mục cho sản phẩm</label>
            <select class="form-control" id="exampleFormControlSelect1" name="category_id">
                <option value="">Chọn danh mục</option>
                <?php echo $htmlOption; ?>

            </select>
          </div>
        <div class="form-group">
            <label>Nội dung</label>
            <textarea class="form-control tinymce_editor_product"  rows="10" name="content"><?php echo $product->content; ?></textarea>
        </div>
        <div class="form-group">
            <label>Ảnh sản phẩm</label>
            <input type="file"
                   class="form-control-file"
                   name="image_path"
            >
            <div class="col-md-4 feature_image_container">
                <div class="row">
                    <img class="feature_image" width="200" src="<?php echo e($product->image_path); ?>" alt="">
                </div>
            </div>
        </div>
        <div class="form-check mb-3">
            <input class="form-check-input" type="checkbox" value="1" name="related_product"
            <?php if($product->related_product == 1): ?>
                <?php echo e("checked"); ?>

            <?php endif; ?>
            id="defaultCheck1">
            <label class="form-check-label" for="defaultCheck1">
              Hiển thị là sản phẩm nổi bật
            </label>
        </div>
        <button type="submit" class="btn btn-primary">Sửa sản phẩm</button>
        <button type="button" class="btn btn-info"><a href="<?php echo e(route('products.index')); ?>" style="color: white;text-decoration: none;"> Trở về</a></button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\webnoithat\resources\views/dashboard/pages/products/edit.blade.php ENDPATH**/ ?>