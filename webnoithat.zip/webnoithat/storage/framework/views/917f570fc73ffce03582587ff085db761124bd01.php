<div class="slider owl-carousel owl-theme">
    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sliderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="slider__item"><img src="<?php echo e($sliderItem->image_path); ?>" alt="slider-img" title="#caption1">
            <div class="overlay"></div>
            <div class="slider__item-text"  style="width:100%;">
                <div class="container">
                    <div class="row">
                        <div class="col-8">
                                <h1 style="color: white;"><?php echo e($sliderItem->title); ?></h1>
                                <p style="color: white"><?php echo e($sliderItem->description); ?></p>
                                <div class="btn btn-primary">
                                <a style="color: white;" href="<?php echo e(getConfig('button-xem-them-slider')); ?>">Xem Thêm</a>
                                </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div><?php /**PATH D:\xampp\htdocs\webnoithat\resources\views/frontend/components/home/slider.blade.php ENDPATH**/ ?>