<div class="footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="footer__item"><a class="footer__logo mb-3"><img
                            src="<?php echo e($logo->image_path); ?>" alt="logo"></a>
                    <h3 class="footer__company"><?php echo e(getConfig('name-company')); ?></h3><a class="footer__link mb-3"
                href="<?php echo e(getConfig('gioi-thieu-ve-chung-toi-footer')); ?>"><i class="fas fa-arrow-circle-right"></i>Giới thiệu về chúng tôi</a>
                    <div class="footer__fanpage"><iframe
                        src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FBig-I-Home-Thi%25E1%25BA%25BFt-K%25E1%25BA%25BF-Ki%25E1%25BA%25BFn-Tr%25C3%25BAc-N%25E1%25BB%2599i-Th%25E1%25BA%25A5t-104555761373841%2F&amp;tabs=timeline&amp;width=242&amp;height=210&amp;small_header=false&amp;adapt_container_width=true&amp;hide_cover=false&amp;show_facepile=true&amp;appId=168015681053039"
                        width="240" height="210" style="border:none;overflow:hidden" scrolling="no" frameborder="0"
                        allowtransparency="true" allow="encrypted-media"></iframe></div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="footer__item">
                    <h3 class="footer__title">Tin mới nhất</h3>
                    <ul class="footer__list">
                        <?php $__currentLoopData = $postCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postCategoryItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="footer__post"><i class="fas fa-caret-right"></i><a class="footer__link" href="<?php echo e(route('category-new.new',['slug'=>$postCategoryItem->slug,'id'=>$postCategoryItem->id])); ?>">
                            <?php echo e($postCategoryItem->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="footer__item">
                    <h3 class="footer__title">Thông tin liên hệ</h3>
                    <ul class="footer__information">
                        <h3 class="footer__company"><?php echo e(getConfig('ten-cty')); ?></h3>
                        <li><i class="fas fa-map-marker-alt"></i><?php echo e(getConfig('dia-chi')); ?></li>
                        <li><i class="fas fa-mobile"></i><?php echo e(getConfig('phone')); ?></li>
                        <li><i class="fas fa-envelope"></i> <?php echo e(getConfig('email')); ?></li>
                        <li><i class="fas fa-globe"></i><a style="color: white"
                                href="<?php echo e(getConfig('website')); ?>"><?php echo e(getConfig('website')); ?></a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="footer__item">
                    <h3 class="footer__title">Liên hệ</h3>
                    <div class="footer__contact">
                        <p>Để lại thông tin, lời nhắn cho chúng tôi để được hỗ trợ, tư vấn kịp thời.</p>
                        <form method="POST" action="<?php echo e(route('customer.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="footer-contact" id="submit-footer-form"
                                data-url="<?php echo e(route('customer.store')); ?>">
                                <div class="form-group">
                                    <input class="form-control" name="name" type="text" aria-describedby="emailHelp"
                                        placeholder="Họ và tên">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" name="email" type="email" aria-describedby="emailHelp"
                                        placeholder="Email">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" name="phone" type="tel" placeholder="Số điện thoại">
                                </div>
                                <div class="form-group">
                                    <textarea class="form-control" id="footertext" name="content" rows="3"></textarea>
                                </div>
                                <button class="btn btn-primary" type="submit" id="submitFooter">Gửi đi</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </footer>
    <div class="copyright mt-4">
        <div class="container">
            <div class="row">
                <div class="col-sm-8">
                    <p><?php echo e(getConfig('copy-right')); ?></p>
                </div>
                <div class="col-sm-4">
                    <ul class="copyright__social">
                        <li class="copyright__social-item"><a class="copyright__social-link"
                                href="<?php echo e(getConfig('link-fb')); ?>"><i class="fab fa-facebook-f"></i></a></li>
                        <li class="copyright__social-item"><a class="copyright__social-link"
                                href="<?php echo e(getConfig('link-fb')); ?>"><i class="fab fa-google"></i></a></li>
                        <li class="copyright__social-item"><a class="copyright__social-link"
                                href="<?php echo e(getConfig('link-fb')); ?>"><i class="fas fa-envelope"></i></a></li>
                        <li class="copyright__social-item"><a class="copyright__social-link"
                                href="<?php echo e(getConfig('link-fb')); ?>"><i class="fab fa-youtube"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End Footer-->
    <!-- Back to Top-->
    <div id="ts-back-to-top-wrap"><a class="smoothscroll-up" id="ts-back-to-top" href="#wrap"><i
                class="fa fa-arrow-up"></i></a></div>
</div>
<?php $__env->startSection('js'); ?>
    <script>
        function submitFormCustomer(e) {
            e.preventDefault();
            var formWrapper = $("#submit-footer-form"); // từ cái id mình lấy dc cái div bao quanh f
            // var formWrapper = $(id_cua_form);
            var dataUrl = formWrapper.data('url');
            var _token = $("input[name='_token']").val();
            var name = $("input[name='name']").val();
            var email = $("input[name='email']").val();
            var phone = $("input[name='phone']").val();
            var content = $("#footertext").val();
            $.ajax({
                url: dataUrl,
                type: 'POST',
                data: {
                    _token: _token,
                    name: name,
                    email: email,
                    phone: phone,
                    content: content
                },
                beforeSend: function() {
                    // Show image container
                    $("#loader").show();
                },
                success: function(response) {
                    let dataHtmlSuccess = `
                        <div class="form-group">
                        <input class="form-control" name="name" type="text" aria-describedby="emailHelp" placeholder="Họ và tên">
                      </div>
                      <div class="form-group">
                        <input class="form-control" name="email" type="email" aria-describedby="emailHelp" placeholder="Email">
                      </div>
                      <div class="form-group">
                        <input class="form-control" name="phone" type="tel" placeholder="Số điện thoại">
                      </div>
                      <div class="form-group">
                        <textarea class="form-control" id="footertext" name="content" rows="3"></textarea>
                      </div>
                      <button class="btn btn-primary" type="submit" id="submitFooter">Gửi đi</button>
                                <p style="color: green;
                                    margin-top: 20px;
                                    padding: 20px 10px 20px 10px;

                                    background: white;
                                    font-weight: 700;">Gửi yêu cầu thành công,chúng tôi sẽ liên hệ lại sớm nhất !!</p>`
                    if (response.success === "ok") {
                        formWrapper.html(dataHtmlSuccess)
                    }
                },
                complete: function(data) {
                    $("#loader").hide();
                },
                error: function(error) {
                    console.log(error);
                    let dataErrors = `
                        <div class="form-group">
                        <input class="form-control" name="name" type="text" aria-describedby="emailHelp" placeholder="Họ và tên">
                        <p class=" mt-1" style="color:red;font-weight: 700;">${error.responseJSON.errors.name[0]}</p>
                        </div>
                      <div class="form-group">
                        <input class="form-control" name="email" type="email" aria-describedby="emailHelp" placeholder="Email">
                      </div>
                      <div class="form-group">
                        <input class="form-control" name="phone" type="tel" placeholder="Số điện thoại">
                        <p class=" mt-1" style="color:red;font-weight: 700;">${error.responseJSON.errors.phone[0]}</p>
                      </div>
                      <div class="form-group">
                        <textarea class="form-control" id="footertext" name="content" rows="3"></textarea>
                      </div>
                      <button class="btn btn-primary" type="submit" id="submitFooter">Gửi đi</button>
                                <p style="color:green;margin-top: 20px;
                                    padding: 20px 20px 20px 10px;
                                    background: white;
                                    font-weight: 700;">Gửi yêu cầu thất bại, vui lòng thử lại</p>`
                    formWrapper.html(dataErrors)
                }
            });
        }
        $(function() {
            $("#submitFooter").on('click', submitFormCustomer)
        })

    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH D:\xampp\htdocs\webnoithat\resources\views/frontend/layouts/footer.blade.php ENDPATH**/ ?>