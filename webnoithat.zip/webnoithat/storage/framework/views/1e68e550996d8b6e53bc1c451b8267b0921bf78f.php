<div class="services section">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <h2 class="services__title title">Dịch vụ & sản phẩm của chúng tôi dành cho ai?</h2>
        </div>
        <?php $__currentLoopData = $serviceUps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-6 col-lg-3">
            <div class="services__item">
            <div class="services__item-img"><img class="img-fluid lazyload"  data-original="<?php echo e($serviceItem->image_path); ?>" alt="service"></div>
              <div class="services__item-content">
                <p><?php echo e($serviceItem->content); ?></p>
              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="col-12">
          <h2 class="services__title title">Tại sao bạn nên chọn chúng tôi ??? </h2>
        </div>
        <?php $__currentLoopData = $serviceDowns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceDownItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6 col-lg-3">
          <div class="services__item">
            <div class="services__item-img"><img class="img-fluid lazyload" data-original="<?php echo e($serviceDownItem->image_path); ?>" alt="service"></div>
            <div class="services__item-content">
              <p><?php echo e($serviceDownItem->content); ?></p>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div><?php /**PATH D:\xampp\htdocs\webnoithat\resources\views/frontend/components/home/service.blade.php ENDPATH**/ ?>