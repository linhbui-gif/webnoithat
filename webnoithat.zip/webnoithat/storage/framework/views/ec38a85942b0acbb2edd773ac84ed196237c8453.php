
<?php $__env->startSection('content'); ?>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <?php echo $__env->make('dashboard.layouts.content-header', ['name' => 'người dùng', 'key' => 'Thông tin'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <a href="<?php echo e(route('users.create')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-plus fa-sm text-white-50"></i> Thông tin người dùng</a>
    </div>
    <ul class="list-group list-group-flush">
        <li class="list-group-item">Họ và Tên : <?php echo e($user->name); ?></li>
        <li class="list-group-item">Email : <?php echo e($user->email); ?></li>
        <li class="list-group-item">Hình ảnh : <img src="<?php echo e($user->image_path); ?>" width="300" alt=""></li>
        <li class="list-group-item">Quyền : <?php echo e($user->roles === 0 ? "admin" : "user"); ?></li>
      </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\webnoithat\resources\views/dashboard/pages/profile/index.blade.php ENDPATH**/ ?>